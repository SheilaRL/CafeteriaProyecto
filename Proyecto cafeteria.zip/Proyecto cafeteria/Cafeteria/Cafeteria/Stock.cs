﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class Stock
    {
        private int codigoProducto;
        private string nombreProducto;
        private int cantidadDisponible;
        private double precioProducto;

        public Stock(int codigoProducto, string nombreProducto, int cantidadDisponible, double precioProducto)
        {
            this.codigoProducto = codigoProducto;
            this.nombreProducto = nombreProducto;
            this.cantidadDisponible = cantidadDisponible;
            this.precioProducto = precioProducto;
        }

        public int getCodigoProducto()
        {
            return codigoProducto;
        }

        public void setCodigoProducto(int codigoProducto)
        {
            this.codigoProducto = codigoProducto;
        }

        public string getNombreProducto()
        {
            return nombreProducto;
        }

        public void setNombreProducto(string nombreProducto)
        {
            this.nombreProducto = nombreProducto;
        }

        public int getCantidadDisponible()
        {
            return cantidadDisponible;
        }

        public void setCantidadDisponible(int cantidadDisponible)
        {
            this.cantidadDisponible = cantidadDisponible;
        }

        public double getPrecioProducto()
        {
            return precioProducto;
        }

        public void setPrecioProducto(double precioProducto)
        {
            this.precioProducto = precioProducto;
        }

        public override string ToString()
        {
            return "Código producto: " + codigoProducto + "\n" +
                "Nombre producto: " + nombreProducto + "\n" +
                "Cantidad en stock: " + cantidadDisponible + "\n" +
                "Precio producto: " + precioProducto;
        }

    }

}
