﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Pedidos : Form
    {
        int posicion = 0;

        public Pedidos()
        {
            InitializeComponent();
        }

        private void Pedidos_Load(object sender, EventArgs e)
        {
          
        }

        

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1Anyadir_Click(object sender, EventArgs e)
        {
            string numeroPedido, mesa, pedido;
            int i = 0;

            numeroPedido = textBox1.Text;
            mesa = textBox2.Text;
            pedido = textBox3.Text;

            dataGridView1.Rows.Add(/*i + " ",*/ numeroPedido, mesa, pedido);
            i = i + 1;

            Clear();
            textBox1.Focus();

        }

        private void Clear()
        {
            button3Eliminar.Enabled = false;
            button2Modificar.Enabled = false;
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int posicion = dataGridView1.CurrentRow.Index;

            textBox1.Text = dataGridView1[1, posicion].Value.ToString();
            textBox2.Text = dataGridView1[2, posicion].Value.ToString();
            textBox3.Text = dataGridView1[3, posicion].Value.ToString();

            /*button1Anyadir.Enabled = false; 
            button2Modificar.Enabled = false;
            button3Eliminar.Enabled = false;*/

            textBox1.Focus();

          
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void button2Modificar_Click(object sender, EventArgs e)
        {
            string numeroPedido, mesa, pedido;

            numeroPedido = textBox1.Text;
            mesa = textBox2.Text;
            pedido = textBox3.Text;

            dataGridView1[1, posicion].Value = numeroPedido;
            dataGridView1[2, posicion].Value = mesa;
            dataGridView1[3, posicion].Value = pedido;

            Clear();
        }

        private void button3Eliminar_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.RemoveAt(posicion);
        }
    }
}
