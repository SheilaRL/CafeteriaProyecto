﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class ReservaMesa
    {
        private Cliente cliente;
        private int codigoReserva;
        private DateTime fechaReserva;
        private DateTime horaReserva;
        private int numeroComensales;
        private string estadoReserva;

        public ReservaMesa(Cliente cliente, int codigoReserva, DateTime fechaReserva, DateTime horaReserva,
            int numeroComensales, string estadoReserva)
        {
            this.cliente = cliente;
            this.codigoReserva = codigoReserva;
            this.fechaReserva = fechaReserva;
            this.horaReserva = horaReserva;
            this.numeroComensales = numeroComensales;
            this.estadoReserva = estadoReserva;
        }

        public Cliente getCliente()
        {
            return cliente;
        }

        public void setCliente(Cliente cliente)
        {
            this.cliente = cliente;
        }

        public int getCodigoReserva()
        {
            return codigoReserva;
        }

        public void setCodigoReserva(int codigoReserva)
        {
            this.codigoReserva = codigoReserva;
        }

        public DateTime getFechaReserva()
        {
            return fechaReserva;
        }

        public void setFechaReserva(DateTime fechaReserva)
        {
            this.fechaReserva = fechaReserva;
        }

        public DateTime getHoraReserva()
        {
            return horaReserva;
        }

        public void setHoraReserva(DateTime horaReserva)
        {
            this.horaReserva = horaReserva;
        }

        public int getNumeroComensales()
        {
            return numeroComensales;
        }

        public void setNumeroComensales(int numeroComensales)
        {
            this.numeroComensales = numeroComensales;
        }

        public string getEstadoReserva()
        {
            return estadoReserva;
        }

        public void setEstadoReserva(string estadoReserva)
        {
            this.estadoReserva = estadoReserva;
        }

        public override string ToString()
        {
            return "Cliente: " + cliente + "\n" +
                "Código reserva: " + codigoReserva + "\n" +
                "Fecha y hora: " + fechaReserva + horaReserva + "\n" +
                "Número de comensales: " + numeroComensales + "\n" +
                "Estado de la reserva: " + estadoReserva;
        }
    }
}
