﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class PedidosWeb
    {
        private Cliente cliente;
        private int codigoPedidoWeb;
        private List<PedidosWeb> pedidosWeb;
        private double precioTotal;
        private DateTime fechaPedido;
        private string estadoPedido;
        private string direccionEntrega;

        public PedidosWeb(Cliente cliente, int codigoPedidoWeb, List<PedidosWeb> pedidosWeb, double precioTotal,
            DateTime fechaPedido, string estadoPedido, string direccionEntrega)
        {
            this.cliente = cliente;
            this.codigoPedidoWeb = codigoPedidoWeb;
            this.pedidosWeb = pedidosWeb;
            this.precioTotal = precioTotal;
            this.fechaPedido = fechaPedido;
            this.estadoPedido = estadoPedido;
            this.direccionEntrega = direccionEntrega;
        }

        public Cliente getCliente()
        {
            return cliente;
        }

        public void setCliente(Cliente cliente) 
        { 
            this.cliente = cliente;
        }

        public int getCodigoPedidoWeb()
        {
            return codigoPedidoWeb;
        }

        public void setCodigoPedidoWeb(int codigoPedidoWeb)
        {
            this.codigoPedidoWeb = codigoPedidoWeb;
        }

        public List<PedidosWeb> getPedidosWeb()
        {
            return pedidosWeb;
        }

        public void setPedidosWeb(List<PedidosWeb> pedidosWeb) 
        { 
            this.pedidosWeb = pedidosWeb;
        }
        
        public double getPrecioTotal()
        {
            return precioTotal;
        }

        public void setPrecioTotal(double precioTotal)
        {
            this.precioTotal = precioTotal;
        }

        public DateTime getFechaPedido()
        {
            return fechaPedido;
        }

        public void setFechaPedido(DateTime fechaPedido)
        {
            this.fechaPedido = fechaPedido;
        }

        public string getEstadoPedido()
        {
            return estadoPedido;
        }

        public void setEstadoPedido(string estadoPedido)
        {
            this.estadoPedido = estadoPedido;
        }

        public string getDireccionEntrega()
        {
            return direccionEntrega;
        }

        public void setDireccionEntrega(string direccionEntrega)
        {
            this.direccionEntrega = direccionEntrega;
        }

        public override string ToString()
        {
            return "Cliente: " + cliente + "\n" +
                "Código pedido: " + codigoPedidoWeb + "\n" +
                "Fecha pedido: " + fechaPedido + "\n" +
                "Dirección de entrega: " + direccionEntrega + "\n" +
                "Precio total: " + precioTotal;
        }
    }
}
