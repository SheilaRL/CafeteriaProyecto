﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Pedido : Form
    {
        private ListaPedidos listaPedidos;

        public Pedido(ListaPedidos listaPedidos)
        {
            InitializeComponent();
            listaPedidos = new ListaPedidos();
            this.listaPedidos = listaPedidos;
            actualizarDataGridView();
        }

        public Pedido()
        {
        }

        public void Pedido_Load(object sender, EventArgs e)
        {
            actualizarDataGridView();
        }


        public void anyadirFila(string numeroPedido, string mesa, string pedido)
        {
            comandaBindingSource.Add(new Comanda()
            {
                NumeroPedido = numeroPedido,
                Mesa = mesa,
                Pedido = pedido
            });
        }

        public void button1Anyadir_Click(object sender, EventArgs e)
        {

            string numeroPedido = textBox1.Text;
            string mesa = textBox2.Text;
            string pedido = textBox3.Text;

            Comanda nuevaComanda = new Comanda(numeroPedido, mesa, pedido);
            listaPedidos.anyadirPedidos(nuevaComanda);
            actualizarDataGridView();
            Limpiar();
        }

        private void Limpiar()
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
        }

        private void button3Eliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Comanda eliminarPedido = (Comanda)dataGridView1.SelectedRows[0].DataBoundItem;
                listaPedidos.eliminarPedidos(eliminarPedido);
                actualizarDataGridView();
                MessageBox.Show("Pedido eliminado.");
            }

            else
            {
                MessageBox.Show("Por favor, selecciona un pedido para eliminar.");
            }
        }

        public void actualizarDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listaPedidos.getPedidos();

        }

        private void Pedido_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
