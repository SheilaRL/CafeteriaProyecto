﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Cafeteria
{
    public class ListaUsuarios
    {
        private List<Usuario> listaUsuarios;
        private string ruta = "usuarios.txt";

        public ListaUsuarios()
        {
            listaUsuarios = new List<Usuario>();
            cargarUsuarios();
        }

        public List<Usuario> getListaUsuarios()
        {
            return listaUsuarios;
        }

        public void setListaUsuarios(List<Usuario> listaUsuarios)
        {
            this.listaUsuarios = listaUsuarios;
        }

        public void anyadirUsuarios(Usuario usuario)
        {
            listaUsuarios.Add(usuario);
            guardarUsuario();
            MessageBox.Show("Usuario añadido y guardado");
        }

        public void eliminarUsuario(string correo)
        {
            listaUsuarios.RemoveAll(l => l.getCorreo() == correo);
            guardarUsuario();
        }

        public Usuario iniciarSesion(string nombre,string contrasenya)
        {
          return listaUsuarios.Find( l => l.Nombre == nombre && l.Contrasenya == contrasenya);
        }

        public List<Usuario> obtenerLista()
        {
            return listaUsuarios;
        }

        public void cargarUsuarios()
        { 
            try
            {
                if (File.Exists(ruta))
                {
                    using (StreamReader misUsuarios = new StreamReader(ruta))
                    {
                        string linea;

                        while ((linea = misUsuarios.ReadLine()) != null)
                        {
                            if (!string.IsNullOrWhiteSpace(linea))
                            {
                                string[] partes = linea.Split(',');

                                Usuario usuario = new Usuario(
                                     nombre: partes[0],
                                     apellido: partes[1],
                                     correo: partes[2],
                                     contrasenya: partes[3],
                                     numeroTelef: partes[4],
                                     direccion: partes[5],
                                     esCliente: bool.Parse(partes[6]),
                                     esEmpleado: bool.Parse(partes[7])
                                    );

                                listaUsuarios.Add(usuario);
                            }
                        }
                    }
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Error al cargar usuarios");
            }
        }

        public void guardarUsuario()
        {
            try
            {
                using (StreamWriter misUsuarios = new StreamWriter(ruta, false))
                {
                    foreach (Usuario usuario in listaUsuarios)
                    {
                        misUsuarios.WriteLine($"{usuario.Nombre},{usuario.Apellido},{usuario.Correo},{usuario.Contrasenya},{usuario.NumeroTelef}" +
                            $",{usuario.Direccion},{usuario.EsCliente},{usuario.EsEmpleado}");
                    }
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Error al guardar usuarios");
            }
        }


    }
}
