﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class ListaUsuarios
    {
        List<Usuario> listaUsuarios;

        public ListaUsuarios()
        {
            listaUsuarios = new List<Usuario>();
        }

        public void anyadirUsuarios(Usuario usuario)
        {
            listaUsuarios.Add(usuario);
        }
    }
}
