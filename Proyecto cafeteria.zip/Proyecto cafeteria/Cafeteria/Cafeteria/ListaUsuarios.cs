﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class ListaUsuarios
    {
        List<Usuario> listaUsuarios;
        List<Cliente> clientes;
        List<Empleado> empleados;

        public ListaUsuarios()
        {
            listaUsuarios = new List<Usuario>();
            clientes = new List<Cliente>();
            empleados = new List<Empleado>();
        }

        public void anyadirUsuarios(Usuario usuario)
        {

            if (listaUsuarios is Cliente)
            {
                clientes.Add((Cliente)usuario);
            }

            else
            {
                empleados.Add((Empleado)usuario);
            }

            listaUsuarios.Add(usuario);
        }

       
    }
}
