﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public class ListaPedidos
    {
        List<Comanda> listaPedidos;

        private string ruta = "Pedidos.txt";

        public ListaPedidos()
        {
            listaPedidos = new List<Comanda>();
            cargarPedidos();
        }

        public List<Comanda> getPedidos()
        {
            return listaPedidos;
        }

        public void setListaPedidos(List<Comanda> listaPedidos)
        {
            this.listaPedidos = listaPedidos;
        }

        public void anyadirPedidos(Comanda pedidos)
        {
            listaPedidos.Add(pedidos);
            guardarPedidos();
            MessageBox.Show("Pedido añadido");
        }

        public void eliminarPedidos(Comanda pedidos)
        {
            listaPedidos.Remove(pedidos);
            guardarPedidos();
        }

        public List<Comanda> obtenerLista()
        {
            return listaPedidos;
        }

        public void cargarPedidos()
        {
            try
            {
                if (File.Exists(ruta))
                {
                    using (StreamReader misPedidos = new StreamReader(ruta))
                    {
                        string linea;

                        while ((linea = misPedidos.ReadLine()) != null)
                        {
                            if (!string.IsNullOrWhiteSpace(linea))
                            {
                                string [] partes = linea.Split(',');

                                if (partes.Length == 3)
                                {
                                    Comanda pedido = new Comanda(
                                        numeroPedido: partes[0],
                                        mesa: partes[1],
                                        pedido: partes[2]
                                        );

                                    listaPedidos.Add(pedido);
                                }

                                else
                                {
                                    MessageBox.Show("Error");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al cargar los pedidos");
            }
        }
        
        public void guardarPedidos()
        {
            try
            {
                using (StreamWriter misPedidos = new StreamWriter(ruta, false))
                {
                    foreach (Comanda pedidos in listaPedidos)
                    {
                        misPedidos.WriteLine($"{pedidos.NumeroPedido}, {pedidos.Mesa}, {pedidos.Pedido}");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al guardar los pedidos");
            }
        }


      
    }
}
