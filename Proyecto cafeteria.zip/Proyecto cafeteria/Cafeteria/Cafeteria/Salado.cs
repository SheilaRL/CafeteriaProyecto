﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class Salado : Producto
    {
        private int codigoSalado;
        private string nombreSalado;
        private double precioSalado;
        private int stock;
        private string tipoSalado;

        public Salado(int idProducto, string nombreProducto, double precioProducto, 
            int stockProducto, List<Producto> listaProductos) 
            : base(idProducto, nombreProducto, precioProducto, stockProducto, listaProductos)
        {
        }

        public int getCodigoSalado()
        {
            return codigoSalado;
        }

        public void setCodigoSalado(int codigoSalado)
        {
            this.codigoSalado = codigoSalado;
        }

        public string getNombreSalado()
        {
            return nombreSalado;
        }

        public void setNombreSalado(string nombreSalado)
        {
            this.nombreSalado = nombreSalado;
        }

        public double getPrecioSalado()
        {
            return precioSalado;
        }

        public void setPrecioSalado(double precioSalado)
        {
            this.precioSalado = precioSalado;
        }

        public int getStock()
        {
            return stock;
        }

        public void setStock(int stock)
        {
            this.stock = stock;
        }

        public string getTipoSalado()
        {
            return tipoSalado;
        }

        public void setTipoSalado(string tipoSalado)
        {
            this.tipoSalado = tipoSalado;
        }
    }
}
