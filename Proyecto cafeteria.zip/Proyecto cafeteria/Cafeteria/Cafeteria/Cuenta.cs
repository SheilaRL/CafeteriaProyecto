﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Cafeteria
{
    public partial class Cuenta : Form
    {
        public Cuenta()
        {
            InitializeComponent();
        }

        private void botonSalir_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1Anyadir_Click(object sender, EventArgs e)
        {
          
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewRow fila = new DataGridViewRow();
            fila.CreateCells(dataGridView1);

            fila.Cells[0].Value = label12.Text;
            fila.Cells[1].Value = label14.Text;
            fila.Cells[2].Value = label13.Text;
            fila.Cells[3].Value = textBox4.Text;
            fila.Cells[4].Value = (float.Parse(label13.Text) * float.Parse(textBox4.Text)).ToString();

            dataGridView1.Rows.Add(fila);

            label12.Text = label14.Text = label13.Text = textBox4.Text = " ";

            sacarTotal();
        }


        private void Cuenta_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            try
            {
                label10.Text = (float.Parse(textBox5.Text) - float.Parse(label8.Text)).ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void comboProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            int codigo;
            string nombre;
            float precio;

            codigo = comboProductos.SelectedIndex;
            nombre = comboProductos.SelectedItem.ToString();
            precio = comboProductos.SelectedIndex;

            switch (codigo)
            {
                case 0:
                    label12.Text = "0000";
                    break;
                case 1:
                    label12.Text = "0101";
                    break;
                default:
                    label12.Text = "0011";
                    break;
            }

            switch (nombre)
            {
                case "Cafes":
                    label14.Text = "Cafes";
                    break;
                case "Salado":
                    label14.Text = "Salado";
                    break;
                case "Dulce":
                    label14.Text = "Dulce";
                    break;
            }

            switch (precio)
            {
                case 0:
                    label13.Text = "1,50";
                    break;
                case 1:
                    label13.Text = "3,10";
                    break;
                case 2:
                    label13.Text = "2,50";
                    break;
            }
        }

        public void sacarTotal()
        {
            float totalPedido = 0;
            int contador = 0;

            contador = dataGridView1.RowCount;

            for (int i = 0; i < contador; i++)
            {
                totalPedido += float.Parse(dataGridView1.Rows[i].Cells[4].Value.ToString());
            }

            label8.Text = totalPedido.ToString();   
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult eliminar = MessageBox.Show("Estás seguro que deseas eliminar?",
                    "Eliminado", MessageBoxButtons.YesNo,MessageBoxIcon.Question);

                if (eliminar == DialogResult.Yes)
                {
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
                }

            }
            catch (Exception)
            {

                throw;
            }

            sacarTotal();
        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Gracias por la compra, vuelva pronto!");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
