﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class Comanda
    {
        private string numeroPedido;
        private string mesa;
        private string pedido;

        public Comanda()
        {
        }

        public Comanda(string numeroPedido, string mesa, string pedido)
        {
            this.NumeroPedido = numeroPedido;
            this.Mesa = mesa;
            this.Pedido = pedido;
        }

        public string NumeroPedido { get => numeroPedido; set => numeroPedido = value; }
        public string Mesa { get => mesa; set => mesa = value; }
        public string Pedido { get => pedido; set => pedido = value; }

        public override string ToString()
        {
            return numeroPedido + mesa + pedido;


        }


    }
}
