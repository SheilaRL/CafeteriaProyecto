﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class Comanda
    {
        private Cliente cliente;
        private int codigoComanda;
        private List<Comanda> listaComandas;
        private double precioFinal;
        private string estadoComanda;

        public Comanda(Cliente cliente, int codigoComanda, List<Comanda> listaComandas, double precioFinal, string estadoComanda)
        {
            this.cliente = cliente;
            this.codigoComanda = codigoComanda;
            this.listaComandas = listaComandas;
            this.precioFinal = precioFinal;
            this.estadoComanda = estadoComanda;
        }

        public Cliente getCliente()
        {
            return cliente;
        }

        public void setCliente(Cliente cliente)
        {
            this.cliente = cliente;
        }

        public int getCodigoComanda()
        {
            return codigoComanda;
        }

        public void setCodigoComanda(int codigoComanda)
        {
            this.codigoComanda = codigoComanda;
        }

        public List<Comanda> getListaComandas()
        {
            return listaComandas;
        }

        public void setListaComandas(List<Comanda> listaComandas)
        {
            this.listaComandas = listaComandas;
        }

        public double getPrecioFinal()
        {
            return precioFinal;
        }

        public void setPrecioFinal(double precioFinal)
        {
            this.precioFinal = precioFinal;
        }

        private string getEstadoComanda()
        {
            return estadoComanda;   
        }
        
        public void setEstadoComanda(string estadoComanda)
        {
            this.estadoComanda = estadoComanda;
        }

        public override string ToString()
        {
            return "Cliente: " + cliente + "\n" +
                "Código comanda: " + codigoComanda + "\n" +
                "Precio final: " + precioFinal + "\n";


        }


    }
}
