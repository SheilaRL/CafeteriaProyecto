﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public class ListaStock
    {
        List<Producto> listaStock;

        private string ruta = "Stock.txt";

        public ListaStock()
        {
            listaStock = new List<Producto>();
            cargarStock();
        }

        public List<Producto> getListaStock()
        {
            return listaStock;
        }

        public void setListaStock(List<Producto> listaStock)
        {
            this.listaStock = listaStock;
        }

        public void anyadirStock(Producto stock)
        {
            listaStock.Add(stock);
            guardarStock();
            MessageBox.Show("Stock añadido");
        }

        public void eliminarStock(Producto stock)
        {
            listaStock.Remove(stock);
            guardarStock();
        }

        public List<Producto> obtenerLista()
        {
            return listaStock;
        }

        public void cargarStock()
        {
            try
            {
                if (File.Exists(ruta))
                {
                    using (StreamReader miStock = new StreamReader(ruta))
                    {
                        string linea;

                        while ((linea = miStock.ReadLine()) != null)
                        {
                            if (!string.IsNullOrWhiteSpace(linea))
                            {
                                string[] partes = linea.Split(',');

                                if (partes.Length == 4)
                                {
                                    Producto stock = new Producto(
                                        codigoProducto: partes[0],
                                        nombreProducto: partes[1],
                                        cantidad: partes[2],
                                        precioProducto: partes[3]
                                        );

                                    listaStock.Add(stock);
                                }

                                else
                                {
                                    MessageBox.Show("Error");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al cargar el stock");
            }
        }

        public void guardarStock()
        {
            try
            {
                using (StreamWriter miStock = new StreamWriter(ruta, false))
                {
                    foreach (Producto stock in listaStock)
                    {
                        miStock.WriteLine($"{stock.CodigoProducto}, {stock.NombreProducto}, {stock.Cantidad}, {stock.PrecioProducto}");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al guardar el stock");
            }
        }
    }
}
