﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class Usuario
    {
        private string nombre;
        private string apellido;
        private string correo;
        private string contrasenya;
        private string numeroTelef;
        private string direccion;
        private bool esCliente;
        private bool esEmpleado;

        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Correo { get => correo; set => correo = value; }
        public string Contrasenya { get => contrasenya; set => contrasenya = value; }
        public string NumeroTelef { get => numeroTelef; set => numeroTelef = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public bool EsCliente { get => esCliente; set => esCliente = value; }
        public bool EsEmpleado { get => esEmpleado; set => esEmpleado = value; }

        public Usuario(string nombre, string apellido, string correo, string contrasenya, string numeroTelef, string direccion, bool esCliente, bool esEmpleado)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Correo = correo;
            this.Contrasenya = contrasenya;
            this.NumeroTelef = numeroTelef;
            this.Direccion = direccion;
            this.EsCliente = esCliente;
            this.EsEmpleado = esEmpleado;
        }

        public string getNombre() 
        { 
            return Nombre;
        }

        public string getApellido()
        {
            return Apellido;
        }

        public string getCorreo()
        {
            return Correo;
        }

        public string getContrasenya()
        {
            return Contrasenya;
        }


        public void setNombre (string nombre)
        {
            this.Nombre = nombre;
        }

        public void setApellido(string apellido)
        {
            this.Apellido = apellido;
        }

        public void setContrasenya(string contrasenya)
        {
            this.Contrasenya = contrasenya;
        }

        public string getNumeroTelef()
        {
            return NumeroTelef;
        }

        public void setNumeroTelef(string numeroTelef)
        {
            this.NumeroTelef = numeroTelef;
        }

        public string getDireccion()
        {
            return Direccion;
        }

        public void setDireccion(string direccion)
        {
            this.Direccion = direccion;
        }

        public override string ToString()
        {
            return Nombre + Apellido + Correo + "\n " +
                Contrasenya + NumeroTelef + Direccion;
        }

    }
}
