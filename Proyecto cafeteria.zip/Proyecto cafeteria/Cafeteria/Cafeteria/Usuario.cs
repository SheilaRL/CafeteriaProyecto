﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal abstract class Usuario
    {
        private string idUsuario;
        private string nombre;
        private string apellido;
        private string correo;
        private string contrasenya;
        private int numeroTelef;
        private string direccion;
        private string tipoUsuario;


        public Usuario(string idUsuario, string nombre, string apellido, string correo, string contrasenya, string tipoUsuario,
            int numeroTelef, string direccion)
        {
            this.IdUsuario = idUsuario;
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Correo = correo;
            this.Contrasenya = contrasenya;
            this.TipoUsuario = tipoUsuario;
            this.NumeroTelef = numeroTelef;
            this.Direccion = direccion;
        }

        public Usuario()
        {
            IdUsuario = " ";
            Nombre = " ";
            Apellido = " ";
            Correo = " ";
            Contrasenya = " ";
            NumeroTelef = 0;
            Direccion = " ";
            TipoUsuario = " ";
        }

        protected string IdUsuario { get => idUsuario; set => idUsuario = value; }
        protected string Nombre { get => nombre; set => nombre = value; }
        protected string Apellido { get => apellido; set => apellido = value; }
        protected string Correo { get => correo; set => correo = value; }
        protected string Contrasenya { get => contrasenya; set => contrasenya = value; }
        protected string TipoUsuario { get => tipoUsuario; set => tipoUsuario = value; }
        protected int NumeroTelef { get => numeroTelef; set => numeroTelef = value; }
        public string Direccion { get => direccion; set => direccion = value; }

        public string getIdUsuario()
        {
            return IdUsuario;
        }

        public string getNombre() 
        { 
            return Nombre;
        }

        public string getApellido()
        {
            return Apellido;
        }

        public string getCorreo()
        {
            return Correo;
        }

        public string getContrasenya()
        {
            return Contrasenya;
        }

        public string getTipoUsuario()
        {
            return TipoUsuario;
        }

        public void setIdUsuario(string idUsuario)
        {
            this.IdUsuario = idUsuario; 
        }

        public void setNombre (string nombre)
        {
            this.Nombre = nombre;
        }

        public void setApellido(string apellido)
        {
            this.Apellido = apellido;
        }

        public void setContrasenya(string contrasenya)
        {
            this.Contrasenya = contrasenya;
        }

        public void setTipoUsuario(string tipoUsuario)
        {
            this.TipoUsuario = tipoUsuario;
        }

        public int getNumeroTelef()
        {
            return numeroTelef;
        }

        public void setNumeroTelef(int numeroTelef)
        {
            this.numeroTelef = numeroTelef;
        }

        public string getDireccion()
        {
            return direccion;
        }

        public void setDireccion(string direccion)
        {
            this.direccion = direccion;
        }

        public override string ToString()
        {
            return IdUsuario + ":" + Nombre + Apellido + "," + Correo + "\n " +
                Contrasenya + "," + TipoUsuario;
        }

        public bool RegistroUsuario(string nombreUsurario,string apellidoUsuario,string correoUsuario, string contrasenyaUsuario,
            int numeroTelef, string direccionUsuario)
        {
            if (nombre == nombreUsurario && apellido == apellidoUsuario && correo == correoUsuario && 
                contrasenya == contrasenyaUsuario && numeroTelef == numeroTelef && direccion == direccionUsuario)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

    }
}
