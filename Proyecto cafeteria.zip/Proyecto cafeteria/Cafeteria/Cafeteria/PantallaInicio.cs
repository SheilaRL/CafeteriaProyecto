﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class PantallaInicio : Form
    {
        InicioSesion formularioInicioSesion;
        PantallaRegistro formularioPantallaRegistro;
        private ListaUsuarios listaUsuarios;


        public PantallaInicio()
        {
            InitializeComponent();
            listaUsuarios = new ListaUsuarios();
            listaUsuarios.cargarUsuarios();
            formularioInicioSesion = new InicioSesion(listaUsuarios);
            formularioPantallaRegistro = new PantallaRegistro(listaUsuarios);
        }

        private void PantallaInicio_Load(object sender, EventArgs e)
        {

        }

        private void fotoCafeInicio_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        { 
            //listaUsuarios.getListaUsuarios().Clear();
            listaUsuarios.cargarUsuarios();

            //InicioSesion formularioInicioSesion = new InicioSesion(listaUsuarios);
            formularioInicioSesion.ShowDialog();
        }

        private void boton2Registro_Click(object sender, EventArgs e)
        {

            //listaUsuarios.getListaUsuarios().Clear();
            //listaUsuarios.cargarUsuarios(); 
            //PantallaRegistro formularioPantallaRegistro = new PantallaRegistro(listaUsuarios);
            formularioPantallaRegistro.ShowDialog();

            //listaUsuarios = formularioPantallaRegistro.ListasUsuariosRegistrados;
            listaUsuarios.guardarUsuario();
        }
    }
}
