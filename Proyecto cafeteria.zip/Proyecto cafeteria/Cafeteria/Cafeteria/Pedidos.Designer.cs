﻿namespace Cafeteria
{
    partial class Pedidos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3Eliminar = new System.Windows.Forms.Button();
            this.button2Modificar = new System.Windows.Forms.Button();
            this.button1Anyadir = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column2Grid1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1Grid1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3Grid1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button3Eliminar);
            this.panel1.Controls.Add(this.button2Modificar);
            this.panel1.Controls.Add(this.button1Anyadir);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(851, 571);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(111, 471);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(263, 88);
            this.textBox3.TabIndex = 16;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 473);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Pedido";
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(35, 424);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(151, 23);
            this.textBox2.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 379);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Mesa";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(35, 335);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(151, 23);
            this.textBox1.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Número pedido";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Cafeteria.Properties.Resources.pngtree_perfect_cappuccino_isolated_cartoon_vector_illustrations_picture_image_8710553;
            this.pictureBox1.Location = new System.Drawing.Point(5, -30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(331, 305);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // button3Eliminar
            // 
            this.button3Eliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3Eliminar.Location = new System.Drawing.Point(733, 523);
            this.button3Eliminar.Name = "button3Eliminar";
            this.button3Eliminar.Size = new System.Drawing.Size(89, 36);
            this.button3Eliminar.TabIndex = 8;
            this.button3Eliminar.Text = "Eliminar";
            this.button3Eliminar.UseVisualStyleBackColor = true;
            this.button3Eliminar.Click += new System.EventHandler(this.button3Eliminar_Click);
            // 
            // button2Modificar
            // 
            this.button2Modificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2Modificar.Location = new System.Drawing.Point(601, 523);
            this.button2Modificar.Name = "button2Modificar";
            this.button2Modificar.Size = new System.Drawing.Size(89, 36);
            this.button2Modificar.TabIndex = 7;
            this.button2Modificar.Text = "Modificar";
            this.button2Modificar.UseVisualStyleBackColor = true;
            this.button2Modificar.Click += new System.EventHandler(this.button2Modificar_Click);
            // 
            // button1Anyadir
            // 
            this.button1Anyadir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1Anyadir.Location = new System.Drawing.Point(456, 523);
            this.button1Anyadir.Name = "button1Anyadir";
            this.button1Anyadir.Size = new System.Drawing.Size(89, 36);
            this.button1Anyadir.TabIndex = 6;
            this.button1Anyadir.Text = "Añadir";
            this.button1Anyadir.UseVisualStyleBackColor = true;
            this.button1Anyadir.Click += new System.EventHandler(this.button1Anyadir_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DarkSlateGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2Grid1,
            this.Column1Grid1,
            this.Column3Grid1});
            this.dataGridView1.Location = new System.Drawing.Point(411, 141);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(428, 376);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column2Grid1
            // 
            this.Column2Grid1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = null;
            this.Column2Grid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column2Grid1.HeaderText = "Número pedido";
            this.Column2Grid1.MinimumWidth = 6;
            this.Column2Grid1.Name = "Column2Grid1";
            this.Column2Grid1.ReadOnly = true;
            // 
            // Column1Grid1
            // 
            this.Column1Grid1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1Grid1.HeaderText = "Mesa";
            this.Column1Grid1.MinimumWidth = 6;
            this.Column1Grid1.Name = "Column1Grid1";
            this.Column1Grid1.ReadOnly = true;
            // 
            // Column3Grid1
            // 
            this.Column3Grid1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3Grid1.FillWeight = 150F;
            this.Column3Grid1.HeaderText = "Pedido";
            this.Column3Grid1.MinimumWidth = 6;
            this.Column3Grid1.Name = "Column3Grid1";
            this.Column3Grid1.ReadOnly = true;
            // 
            // Pedidos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(851, 571);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Pedidos";
            this.Text = "Pedidos";
            this.Load += new System.EventHandler(this.Pedidos_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1Anyadir;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3Eliminar;
        private System.Windows.Forms.Button button2Modificar;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2Grid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1Grid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3Grid1;
    }
}