﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class StockPedidos : Form
    {
        private ListaStock listaStock;

        public StockPedidos(ListaStock listaStock)
        {
            InitializeComponent();
            this.listaStock = listaStock;
            //listaStock = new ListaStock();
            actualizarDataGridView();
        }

        public StockPedidos()
        {
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void comprarStockToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void StockPedidos_Load(object sender, EventArgs e)
        {
            actualizarDataGridView();
        }

        public void anyadirFila(string codigoProducto, string nombreProducto, string cantidad, string precioProducto)
        {
            productoBindingSource.Add(new Producto()
            {
                CodigoProducto = codigoProducto,
                NombreProducto = nombreProducto,
                Cantidad = cantidad,
                PrecioProducto = precioProducto
            }); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string codigoProducto = textBox1.Text;
            string nombreProducto = textBox2.Text;
            string cantidad = textBox3.Text;
            string estado = textBox4.Text;

            Producto nuevoStock = new Producto(codigoProducto, nombreProducto, cantidad, estado);
            listaStock.anyadirStock(nuevoStock);
            actualizarDataGridView();
            Limpiar();
  
        }

        private void Limpiar()
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
         
        }

        private void panelCentral_FormClosing(object sender, FormClosingEventArgs e)
        {
    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Producto eliminarStock = (Producto)dataGridView1.SelectedRows[0].DataBoundItem;
                listaStock.eliminarStock(eliminarStock);

                actualizarDataGridView();
            }

            else
            {
                MessageBox.Show("Por favor, selecciona un artículo para eliminar.");
            }
        }

        private void actualizarDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listaStock.getListaStock();
        }
    }
}
