﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Mesa : Form
    {
        private ListaReservas listaReservas;

        public Mesa(ListaReservas listaReservas)
        {
            InitializeComponent();
            this.listaReservas = listaReservas;
            actualizarDataGridView();
        }

        public Mesa()
        {
        }

        private void Mesa_Load(object sender, EventArgs e)
        {
            actualizarDataGridView();            
        }

        public void anyadirFila(string nombre, string horaReserva, string numeroComensales, string fechaReserva, string numeroTelef)
        {
            reservaMesaBindingSource.Add(new ReservaMesa()
            {
                Nombre = nombre,
                HoraReserva = horaReserva,
                FechaReserva = fechaReserva,
                NumeroComensales = numeroComensales,
                NumeroTelefono = numeroTelef
            });
        }

        private void button1Anyadir_Click(object sender, EventArgs e)
        {
            string nombre = textBox2.Text;
            string horaReserva = textBox3.Text;
            string numeroComensales = textBox6.Text;
            string fechaReserva = textBox5.Text;
            string numeroTelef = textBox4.Text;
                
            ReservaMesa nuevaReserva = new ReservaMesa(nombre, horaReserva, fechaReserva, numeroComensales, numeroTelef);
            listaReservas.anyadirReservas(nuevaReserva);
            actualizarDataGridView();
            Limpiar();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void Mesa_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void button2Eliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            { 
                ReservaMesa eliminarReserva = (ReservaMesa)dataGridView2.SelectedRows[0].DataBoundItem;
                listaReservas.eliminarReservas(eliminarReserva);

                actualizarDataGridView();
            }

            else
            {
                MessageBox.Show("Por favor, selecciona una reserva para eliminar.");
            }
        }

        private void actualizarDataGridView()
        {
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = listaReservas.getReservas(); 
        }

        private void Limpiar()
        {

            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
            textBox6.Text = " ";
        }
    }
}
