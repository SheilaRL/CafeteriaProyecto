﻿namespace Cafeteria
{
    partial class InicioEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1InicioEmpleado = new System.Windows.Forms.Panel();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.button1MiCuenta = new System.Windows.Forms.Button();
            this.button2Cuenta = new System.Windows.Forms.Button();
            this.boton3Reserva = new System.Windows.Forms.Button();
            this.boton4Stock = new System.Windows.Forms.Button();
            this.boton5PedidosWeb = new System.Windows.Forms.Button();
            this.boton6Ranking = new System.Windows.Forms.Button();
            this.panel1InicioEmpleado.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1InicioEmpleado
            // 
            this.panel1InicioEmpleado.BackColor = System.Drawing.Color.Teal;
            this.panel1InicioEmpleado.Controls.Add(this.boton6Ranking);
            this.panel1InicioEmpleado.Controls.Add(this.boton5PedidosWeb);
            this.panel1InicioEmpleado.Controls.Add(this.boton4Stock);
            this.panel1InicioEmpleado.Controls.Add(this.boton3Reserva);
            this.panel1InicioEmpleado.Controls.Add(this.button2Cuenta);
            this.panel1InicioEmpleado.Controls.Add(this.button1MiCuenta);
            this.panel1InicioEmpleado.Controls.Add(this.panelLogo);
            this.panel1InicioEmpleado.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1InicioEmpleado.Location = new System.Drawing.Point(0, 0);
            this.panel1InicioEmpleado.Name = "panel1InicioEmpleado";
            this.panel1InicioEmpleado.Size = new System.Drawing.Size(218, 630);
            this.panel1InicioEmpleado.TabIndex = 0;
            // 
            // panelLogo
            // 
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(218, 127);
            this.panelLogo.TabIndex = 0;
            this.panelLogo.Paint += new System.Windows.Forms.PaintEventHandler(this.panelLogoI_Paint);
            // 
            // button1MiCuenta
            // 
            this.button1MiCuenta.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1MiCuenta.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.button1MiCuenta.FlatAppearance.BorderSize = 2;
            this.button1MiCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1MiCuenta.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1MiCuenta.ForeColor = System.Drawing.Color.White;
            this.button1MiCuenta.Location = new System.Drawing.Point(0, 127);
            this.button1MiCuenta.Name = "button1MiCuenta";
            this.button1MiCuenta.Size = new System.Drawing.Size(218, 61);
            this.button1MiCuenta.TabIndex = 1;
            this.button1MiCuenta.Text = "Mi cuenta";
            this.button1MiCuenta.UseVisualStyleBackColor = true;
            this.button1MiCuenta.Click += new System.EventHandler(this.button1MiCuenta_Click);
            // 
            // button2Cuenta
            // 
            this.button2Cuenta.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2Cuenta.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.button2Cuenta.FlatAppearance.BorderSize = 2;
            this.button2Cuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2Cuenta.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2Cuenta.ForeColor = System.Drawing.Color.White;
            this.button2Cuenta.Location = new System.Drawing.Point(0, 188);
            this.button2Cuenta.Name = "button2Cuenta";
            this.button2Cuenta.Size = new System.Drawing.Size(218, 62);
            this.button2Cuenta.TabIndex = 2;
            this.button2Cuenta.Text = "Cuenta";
            this.button2Cuenta.UseVisualStyleBackColor = true;
            this.button2Cuenta.Click += new System.EventHandler(this.button2Cuenta_Click);
            // 
            // boton3Reserva
            // 
            this.boton3Reserva.Dock = System.Windows.Forms.DockStyle.Top;
            this.boton3Reserva.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.boton3Reserva.FlatAppearance.BorderSize = 2;
            this.boton3Reserva.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton3Reserva.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton3Reserva.ForeColor = System.Drawing.Color.White;
            this.boton3Reserva.Location = new System.Drawing.Point(0, 250);
            this.boton3Reserva.Name = "boton3Reserva";
            this.boton3Reserva.Size = new System.Drawing.Size(218, 62);
            this.boton3Reserva.TabIndex = 3;
            this.boton3Reserva.Text = "Reservas";
            this.boton3Reserva.UseVisualStyleBackColor = true;
            this.boton3Reserva.Click += new System.EventHandler(this.boton3Reserva_Click);
            // 
            // boton4Stock
            // 
            this.boton4Stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.boton4Stock.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.boton4Stock.FlatAppearance.BorderSize = 2;
            this.boton4Stock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton4Stock.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton4Stock.ForeColor = System.Drawing.Color.White;
            this.boton4Stock.Location = new System.Drawing.Point(0, 312);
            this.boton4Stock.Name = "boton4Stock";
            this.boton4Stock.Size = new System.Drawing.Size(218, 62);
            this.boton4Stock.TabIndex = 4;
            this.boton4Stock.Text = "Stock";
            this.boton4Stock.UseVisualStyleBackColor = true;
            this.boton4Stock.Click += new System.EventHandler(this.boton4Stock_Click);
            // 
            // boton5PedidosWeb
            // 
            this.boton5PedidosWeb.Dock = System.Windows.Forms.DockStyle.Top;
            this.boton5PedidosWeb.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.boton5PedidosWeb.FlatAppearance.BorderSize = 2;
            this.boton5PedidosWeb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton5PedidosWeb.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton5PedidosWeb.ForeColor = System.Drawing.Color.White;
            this.boton5PedidosWeb.Location = new System.Drawing.Point(0, 374);
            this.boton5PedidosWeb.Name = "boton5PedidosWeb";
            this.boton5PedidosWeb.Size = new System.Drawing.Size(218, 62);
            this.boton5PedidosWeb.TabIndex = 5;
            this.boton5PedidosWeb.Text = "Pedidos Web";
            this.boton5PedidosWeb.UseVisualStyleBackColor = true;
            this.boton5PedidosWeb.Click += new System.EventHandler(this.boton5PedidosWeb_Click);
            // 
            // boton6Ranking
            // 
            this.boton6Ranking.Dock = System.Windows.Forms.DockStyle.Top;
            this.boton6Ranking.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.boton6Ranking.FlatAppearance.BorderSize = 2;
            this.boton6Ranking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton6Ranking.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton6Ranking.ForeColor = System.Drawing.Color.White;
            this.boton6Ranking.Location = new System.Drawing.Point(0, 436);
            this.boton6Ranking.Name = "boton6Ranking";
            this.boton6Ranking.Size = new System.Drawing.Size(218, 62);
            this.boton6Ranking.TabIndex = 6;
            this.boton6Ranking.Text = "Ranking";
            this.boton6Ranking.UseVisualStyleBackColor = true;
            this.boton6Ranking.Click += new System.EventHandler(this.boton6Ranking_Click);
            // 
            // InicioEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1004, 630);
            this.Controls.Add(this.panel1InicioEmpleado);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "InicioEmpleado";
            this.Text = "InicioEmpleado";
            this.Load += new System.EventHandler(this.InicioEmpleado_Load);
            this.panel1InicioEmpleado.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1InicioEmpleado;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button button1MiCuenta;
        private System.Windows.Forms.Button button2Cuenta;
        private System.Windows.Forms.Button boton6Ranking;
        private System.Windows.Forms.Button boton5PedidosWeb;
        private System.Windows.Forms.Button boton4Stock;
        private System.Windows.Forms.Button boton3Reserva;
    }
}