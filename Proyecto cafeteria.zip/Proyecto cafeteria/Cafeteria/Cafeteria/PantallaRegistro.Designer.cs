﻿namespace Cafeteria
{
    partial class PantallaRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.nombreRegistro = new System.Windows.Forms.Label();
            this.textBox1Registro = new System.Windows.Forms.TextBox();
            this.apellidoRegistro = new System.Windows.Forms.Label();
            this.textBox2Registro = new System.Windows.Forms.TextBox();
            this.label3Registro = new System.Windows.Forms.Label();
            this.textBox3Registro = new System.Windows.Forms.TextBox();
            this.label4Registro = new System.Windows.Forms.Label();
            this.textBox4Registro = new System.Windows.Forms.TextBox();
            this.label5Registro = new System.Windows.Forms.Label();
            this.textBox5Registro = new System.Windows.Forms.TextBox();
            this.radioButton1Registro = new System.Windows.Forms.RadioButton();
            this.radioButton2Registro = new System.Windows.Forms.RadioButton();
            this.button1Registro = new System.Windows.Forms.Button();
            this.label6Contraseña = new System.Windows.Forms.Label();
            this.textBox6Contraseña = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(1, -2);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(331, 558);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // nombreRegistro
            // 
            this.nombreRegistro.AutoSize = true;
            this.nombreRegistro.BackColor = System.Drawing.Color.White;
            this.nombreRegistro.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombreRegistro.ForeColor = System.Drawing.Color.Teal;
            this.nombreRegistro.Location = new System.Drawing.Point(377, 89);
            this.nombreRegistro.Name = "nombreRegistro";
            this.nombreRegistro.Size = new System.Drawing.Size(73, 18);
            this.nombreRegistro.TabIndex = 1;
            this.nombreRegistro.Text = "Nombre";
            this.nombreRegistro.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1Registro
            // 
            this.textBox1Registro.BackColor = System.Drawing.Color.White;
            this.textBox1Registro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1Registro.ForeColor = System.Drawing.Color.Black;
            this.textBox1Registro.Location = new System.Drawing.Point(467, 81);
            this.textBox1Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1Registro.Name = "textBox1Registro";
            this.textBox1Registro.Size = new System.Drawing.Size(175, 22);
            this.textBox1Registro.TabIndex = 2;
            this.textBox1Registro.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // apellidoRegistro
            // 
            this.apellidoRegistro.AutoSize = true;
            this.apellidoRegistro.BackColor = System.Drawing.Color.White;
            this.apellidoRegistro.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apellidoRegistro.ForeColor = System.Drawing.Color.Teal;
            this.apellidoRegistro.Location = new System.Drawing.Point(377, 143);
            this.apellidoRegistro.Name = "apellidoRegistro";
            this.apellidoRegistro.Size = new System.Drawing.Size(72, 18);
            this.apellidoRegistro.TabIndex = 3;
            this.apellidoRegistro.Text = "Apellido";
            this.apellidoRegistro.Click += new System.EventHandler(this.apellidoRegistro_Click);
            // 
            // textBox2Registro
            // 
            this.textBox2Registro.BackColor = System.Drawing.Color.White;
            this.textBox2Registro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2Registro.ForeColor = System.Drawing.Color.Black;
            this.textBox2Registro.Location = new System.Drawing.Point(467, 135);
            this.textBox2Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2Registro.Name = "textBox2Registro";
            this.textBox2Registro.Size = new System.Drawing.Size(175, 22);
            this.textBox2Registro.TabIndex = 4;
            // 
            // label3Registro
            // 
            this.label3Registro.AutoSize = true;
            this.label3Registro.BackColor = System.Drawing.Color.White;
            this.label3Registro.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3Registro.ForeColor = System.Drawing.Color.Teal;
            this.label3Registro.Location = new System.Drawing.Point(377, 197);
            this.label3Registro.Name = "label3Registro";
            this.label3Registro.Size = new System.Drawing.Size(52, 18);
            this.label3Registro.TabIndex = 5;
            this.label3Registro.Text = "Email";
            this.label3Registro.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // textBox3Registro
            // 
            this.textBox3Registro.BackColor = System.Drawing.Color.White;
            this.textBox3Registro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3Registro.ForeColor = System.Drawing.Color.Black;
            this.textBox3Registro.Location = new System.Drawing.Point(452, 190);
            this.textBox3Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3Registro.Name = "textBox3Registro";
            this.textBox3Registro.Size = new System.Drawing.Size(175, 22);
            this.textBox3Registro.TabIndex = 6;
            this.textBox3Registro.TextChanged += new System.EventHandler(this.textBox3Registro_TextChanged);
            // 
            // label4Registro
            // 
            this.label4Registro.AutoSize = true;
            this.label4Registro.BackColor = System.Drawing.Color.White;
            this.label4Registro.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4Registro.ForeColor = System.Drawing.Color.Teal;
            this.label4Registro.Location = new System.Drawing.Point(377, 297);
            this.label4Registro.Name = "label4Registro";
            this.label4Registro.Size = new System.Drawing.Size(122, 18);
            this.label4Registro.TabIndex = 7;
            this.label4Registro.Text = "Número móvil";
            this.label4Registro.Click += new System.EventHandler(this.label4Registro_Click);
            // 
            // textBox4Registro
            // 
            this.textBox4Registro.BackColor = System.Drawing.Color.White;
            this.textBox4Registro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4Registro.ForeColor = System.Drawing.Color.Black;
            this.textBox4Registro.Location = new System.Drawing.Point(515, 289);
            this.textBox4Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4Registro.Name = "textBox4Registro";
            this.textBox4Registro.Size = new System.Drawing.Size(175, 22);
            this.textBox4Registro.TabIndex = 8;
            this.textBox4Registro.TextChanged += new System.EventHandler(this.textBox4Registro_TextChanged);
            // 
            // label5Registro
            // 
            this.label5Registro.AutoSize = true;
            this.label5Registro.BackColor = System.Drawing.Color.White;
            this.label5Registro.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5Registro.ForeColor = System.Drawing.Color.Teal;
            this.label5Registro.Location = new System.Drawing.Point(377, 350);
            this.label5Registro.Name = "label5Registro";
            this.label5Registro.Size = new System.Drawing.Size(81, 18);
            this.label5Registro.TabIndex = 9;
            this.label5Registro.Text = "Dirección";
            this.label5Registro.Click += new System.EventHandler(this.label5Registro_Click);
            // 
            // textBox5Registro
            // 
            this.textBox5Registro.BackColor = System.Drawing.Color.White;
            this.textBox5Registro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5Registro.ForeColor = System.Drawing.Color.Black;
            this.textBox5Registro.Location = new System.Drawing.Point(475, 342);
            this.textBox5Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5Registro.Name = "textBox5Registro";
            this.textBox5Registro.Size = new System.Drawing.Size(229, 22);
            this.textBox5Registro.TabIndex = 10;
            this.textBox5Registro.TextChanged += new System.EventHandler(this.textBox5Registro_TextChanged);
            // 
            // radioButton1Registro
            // 
            this.radioButton1Registro.AutoSize = true;
            this.radioButton1Registro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton1Registro.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1Registro.ForeColor = System.Drawing.Color.Teal;
            this.radioButton1Registro.Location = new System.Drawing.Point(432, 402);
            this.radioButton1Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton1Registro.Name = "radioButton1Registro";
            this.radioButton1Registro.Size = new System.Drawing.Size(85, 22);
            this.radioButton1Registro.TabIndex = 11;
            this.radioButton1Registro.TabStop = true;
            this.radioButton1Registro.Text = "Cliente";
            this.radioButton1Registro.UseVisualStyleBackColor = true;
            this.radioButton1Registro.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2Registro
            // 
            this.radioButton2Registro.AutoSize = true;
            this.radioButton2Registro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton2Registro.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2Registro.ForeColor = System.Drawing.Color.Teal;
            this.radioButton2Registro.Location = new System.Drawing.Point(671, 402);
            this.radioButton2Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2Registro.Name = "radioButton2Registro";
            this.radioButton2Registro.Size = new System.Drawing.Size(109, 22);
            this.radioButton2Registro.TabIndex = 12;
            this.radioButton2Registro.TabStop = true;
            this.radioButton2Registro.Text = "Empleado";
            this.radioButton2Registro.UseVisualStyleBackColor = true;
            this.radioButton2Registro.CheckedChanged += new System.EventHandler(this.radioButton2Registro_CheckedChanged);
            // 
            // button1Registro
            // 
            this.button1Registro.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1Registro.ForeColor = System.Drawing.Color.Teal;
            this.button1Registro.Location = new System.Drawing.Point(533, 476);
            this.button1Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1Registro.Name = "button1Registro";
            this.button1Registro.Size = new System.Drawing.Size(136, 46);
            this.button1Registro.TabIndex = 13;
            this.button1Registro.Text = "Enviar";
            this.button1Registro.UseVisualStyleBackColor = true;
            this.button1Registro.Click += new System.EventHandler(this.button1Registro_Click);
            // 
            // label6Contraseña
            // 
            this.label6Contraseña.AutoSize = true;
            this.label6Contraseña.BackColor = System.Drawing.Color.White;
            this.label6Contraseña.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6Contraseña.ForeColor = System.Drawing.Color.Teal;
            this.label6Contraseña.Location = new System.Drawing.Point(377, 245);
            this.label6Contraseña.Name = "label6Contraseña";
            this.label6Contraseña.Size = new System.Drawing.Size(102, 18);
            this.label6Contraseña.TabIndex = 14;
            this.label6Contraseña.Text = "Contraseña";
            this.label6Contraseña.Click += new System.EventHandler(this.label6Contraseña_Click);
            // 
            // textBox6Contraseña
            // 
            this.textBox6Contraseña.BackColor = System.Drawing.Color.White;
            this.textBox6Contraseña.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6Contraseña.ForeColor = System.Drawing.Color.Black;
            this.textBox6Contraseña.Location = new System.Drawing.Point(493, 238);
            this.textBox6Contraseña.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6Contraseña.Name = "textBox6Contraseña";
            this.textBox6Contraseña.Size = new System.Drawing.Size(175, 22);
            this.textBox6Contraseña.TabIndex = 15;
            // 
            // PantallaRegistro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(940, 554);
            this.Controls.Add(this.textBox6Contraseña);
            this.Controls.Add(this.label6Contraseña);
            this.Controls.Add(this.button1Registro);
            this.Controls.Add(this.radioButton2Registro);
            this.Controls.Add(this.radioButton1Registro);
            this.Controls.Add(this.textBox5Registro);
            this.Controls.Add(this.label5Registro);
            this.Controls.Add(this.textBox4Registro);
            this.Controls.Add(this.label4Registro);
            this.Controls.Add(this.textBox3Registro);
            this.Controls.Add(this.label3Registro);
            this.Controls.Add(this.textBox2Registro);
            this.Controls.Add(this.apellidoRegistro);
            this.Controls.Add(this.textBox1Registro);
            this.Controls.Add(this.nombreRegistro);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "PantallaRegistro";
            this.Text = "PantallaRegistro";
            this.Load += new System.EventHandler(this.PantallaRegistro_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label nombreRegistro;
        private System.Windows.Forms.TextBox textBox1Registro;
        private System.Windows.Forms.Label apellidoRegistro;
        private System.Windows.Forms.TextBox textBox2Registro;
        private System.Windows.Forms.Label label3Registro;
        private System.Windows.Forms.TextBox textBox3Registro;
        private System.Windows.Forms.Label label4Registro;
        private System.Windows.Forms.TextBox textBox4Registro;
        private System.Windows.Forms.Label label5Registro;
        private System.Windows.Forms.TextBox textBox5Registro;
        private System.Windows.Forms.RadioButton radioButton1Registro;
        private System.Windows.Forms.RadioButton radioButton2Registro;
        private System.Windows.Forms.Button button1Registro;
        private System.Windows.Forms.Label label6Contraseña;
        private System.Windows.Forms.TextBox textBox6Contraseña;
    }
}