﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class mesasOpcion : Form
    {

        public mesasOpcion()
        {
            InitializeComponent();


        }


        private void mesasOpcion_Load(object sender, EventArgs e)
        {
          
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1Anyadir_Click(object sender, EventArgs e)
        {
            string nombre, horaReserva, numeroPersonas, fechaReserva, numeroTelef;
            int i = 0;

            nombre = textBox2.Text;
            horaReserva = textBox3.Text;
            numeroPersonas = textBox6.Text;
            fechaReserva = textBox5.Text;
            numeroTelef = textBox4.Text;

            dataGridView2.Rows.Add(/*i + " ",*/ nombre, fechaReserva, horaReserva, numeroPersonas, numeroTelef);
            i = i + 1;

            Clear();
            textBox2.Focus();
        }

        private void Clear()
        {
            button1Anyadir.Enabled = false;
            button2Eliminar.Enabled = false;
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
            textBox6.Text = " ";
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int posicion = dataGridView2.CurrentRow.Index;

            textBox2.Text = dataGridView2[1, posicion].Value.ToString();
            textBox3.Text = dataGridView2[2, posicion].Value.ToString();
            textBox4.Text = dataGridView2[3, posicion].Value.ToString();
            textBox5.Text = dataGridView2[4, posicion].Value.ToString();
            textBox6.Text = dataGridView2[5, posicion].Value.ToString();

            button1Anyadir.Enabled = false;
            button2Eliminar.Enabled = false;

            textBox2.Focus();

        }
    }
}
