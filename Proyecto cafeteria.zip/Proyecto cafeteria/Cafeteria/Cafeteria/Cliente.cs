﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class Cliente : Usuario
    {
        private int puntosRanking;

        public Cliente(string nombre, string apellido, string correo, string contrasenya, int numeroTelef, string direccion) :
            base()
        {

        }

        public int getPuntosRanking()
        {
            return puntosRanking;
        }

        public void setPuntosRanking(int puntosRanking)
        {
            this.puntosRanking = puntosRanking;
        }

        public override string ToString()
        {
            return base.ToString() + puntosRanking;
        }
    }
}
