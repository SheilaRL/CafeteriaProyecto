﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public class ListaReservas
    {
        List<ReservaMesa> listaReservas;

        private string ruta = "Reservas.txt";

        public ListaReservas()
        {
            listaReservas = new List<ReservaMesa>();
            cargarReservas();
        }

        public List<ReservaMesa> getReservas()
        {
            return listaReservas;
        }

        public void setListaReservas(List<ReservaMesa> listaReservas)
        {
            this.listaReservas = listaReservas;
        }

        public void anyadirReservas(ReservaMesa reservas)
        {
            listaReservas.Add(reservas);
            guardarReservas();
            MessageBox.Show("Reserva añadida");
        }

        public void eliminarReservas(ReservaMesa reserva)
        {
            listaReservas.Remove(reserva);
            guardarReservas();
        }

        public List<ReservaMesa> obtenerLista()
        {
            return listaReservas;
        }

        public void cargarReservas()
        {
           
                try
                {
                    if (File.Exists(ruta))
                    {
                        using (StreamReader misReservas = new StreamReader(ruta))
                        {
                            string linea;

                            while ((linea = misReservas.ReadLine()) != null)
                            {
                                if (!string.IsNullOrWhiteSpace(linea))
                                {
                                    string[] partes = linea.Split(',');

                                    if (partes.Length == 5)
                                    {
                                        ReservaMesa reserva = new ReservaMesa(
                                           nombre: partes[0],
                                           horaReserva: partes[1],
                                           fechaReserva: partes[2],
                                           numeroComensales: partes[3],
                                           numeroTelefono: partes[4]
                                           );

                                        listaReservas.Add(reserva);
                                    }

                                    else
                                    {
                                        MessageBox.Show("Error");
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Error al cargar las reservas");
                }
        }

        public void guardarReservas()
        {
            try
            {
                using (StreamWriter misReservas = new StreamWriter(ruta, false))
                {
                    foreach (ReservaMesa reserva in listaReservas)
                    {
                        misReservas.WriteLine($"{reserva.Nombre}, {reserva.HoraReserva}, {reserva.FechaReserva}, {reserva.NumeroComensales}," +
                            $"{reserva.NumeroTelefono}");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al guardar las reservas");
            }
        }
    }
}
