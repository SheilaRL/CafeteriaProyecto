﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class panelCliente : Form
    {
        public panelCliente()
        {
            InitializeComponent();
        }

        public void anyadirContoles(Form f)
        {
            panel2Cliente.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel2Cliente.Controls.Add(f);
            f.Show();
        }

        private void InicioCliente_Load(object sender, EventArgs e)
        {

        }

        private void panel2Cliente_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1Logo_Click(object sender, EventArgs e)
        {

        }

        private void button1Cuenta_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(label13.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    MessageBox.Show("Por favor, selecciona todos los campos.");
                }

                if (!float.TryParse(textBox4.Text, out float precio))
                {
                    MessageBox.Show("Precio no válido");
                }

                if (!float.TryParse(label13.Text, out float cantidad))
                {
                    MessageBox.Show("Cantidad no válida");
                }

                DataGridViewRow fila = new DataGridViewRow();
                fila.CreateCells(dataGridView1);

                fila.Cells[0].Value = label13.Text;
                fila.Cells[1].Value = textBox4.Text;
                fila.Cells[2].Value = label2.Text;
                fila.Cells[3].Value = (precio * cantidad).ToString();

                dataGridView1.Rows.Add(fila);
                label13.Text = textBox4.Text = label2.Text = " ";

                sacarTotal();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            float precio;
            string nombre;

            precio = comboProductos.SelectedIndex;
            nombre = comboProductos.SelectedItem.ToString();

            switch (nombre)
            {
                case "Café con leche":
                    label2.Text = "Café con leche";
                    break;
                case "Café Latte":
                    label2.Text = "Café Latte";
                    break;
                case "Café Espresso":
                    label2.Text = "Café Espresso";
                    break;
                case "Café Americano":
                    label2.Text = "Café Americano";
                    break;
                case "Capuccino":
                    label2.Text = "Capuccino";
                    break;
                case "Tostada con tomate":
                    label2.Text = "Tostada con tomate";
                    break;
                case "Tostada con salmón":
                    label2.Text = "Tostada con salmón";
                    break;
                case "Tostada con aguacate":
                    label2.Text = "Tostada con aguacate";
                    break;
                case "Tortitas":
                    label2.Text = "Tortitas";
                    break;
                case "Tortitas con chocolate":
                    label2.Text = "Tortitas con chocolate";
                    break;
                case "Tortitas con nata y plátano":
                    label2.Text = "Tortitas con nata y plátano";
                    break;
            }

            switch (precio)
            {
                case 0:
                    label13.Text = "1.20€";
                    break;
                case 1:
                    label13.Text = "1.50€";
                    break;
                case 2:
                    label13.Text = "1.30€";
                    break;
                case 3:
                    label13.Text = "1.40€";
                    break;
                case 4:
                    label13.Text = "2€";
                    break;
                case 5:
                    label13.Text = "2€";
                    break;
                case 6:
                    label13.Text = "2.50€";
                    break;
                case 7:
                    label13.Text = "2.30€";
                    break;
                case 8:
                    label13.Text = "2€";
                    break;
                case 9:
                    label13.Text = "2.30€";
                    break;
                case 10:
                    label13.Text = "3€";
                    break;
            }
        }


        public void sacarTotal()
        {
            float totalPedido = 0;
            int contador = 0;

            contador = dataGridView1.RowCount;

            for (int i = 0; i < contador; i++)
            {
                if (dataGridView1.Rows[i].Cells[3].Value != null && !string.IsNullOrWhiteSpace(dataGridView1.Rows[i].Cells[3].Value.ToString()))
                {
                    totalPedido += float.Parse(dataGridView1.Rows[i].Cells[3].Value.ToString());
                }
            }

            label8.Text = totalPedido.ToString();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                DialogResult eliminar = MessageBox.Show("Estás seguro que deseas eliminar?",
                    "Eliminado", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (eliminar == DialogResult.Yes)
                {
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Error al eliminar.");
            }

            sacarTotal();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
