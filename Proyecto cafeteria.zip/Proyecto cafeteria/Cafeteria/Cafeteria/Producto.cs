﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class Producto
    {
        private string codigoProducto;
        private string nombreProducto;
        private string cantidad;
        private string precioProducto;

        public string CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string NombreProducto { get => nombreProducto; set => nombreProducto = value; }
        public string Cantidad { get => cantidad; set => cantidad = value; }
        public string PrecioProducto { get => precioProducto; set => precioProducto = value; }

        public Producto(string codigoProducto, string nombreProducto, string cantidad, string precioProducto)
        {
            this.CodigoProducto = codigoProducto;
            this.NombreProducto = nombreProducto;
            this.Cantidad = cantidad;
            this.PrecioProducto = precioProducto;
        }

        public Producto()
        {
        }

        public string getcodigoProducto()
        {
            return CodigoProducto;
        }

        public void setcodigoProducto(string codigoProducto)
        {
            this.CodigoProducto = codigoProducto;
        }

        public string getNombreProducto()
        {
            return NombreProducto;
        }

        public void setNombreProducto(string nombreProducto)
        {
            this.NombreProducto = nombreProducto;
        }

        public string getPrecioProducto()
        {
            return PrecioProducto;
        }

        public void setPrecioProducto(string precioProducto)
        {
            this.PrecioProducto = precioProducto;
        }

        public string getCantidad()
        {
            return Cantidad;
        }

        public void setCantidad(string cantidad)
        {
            this.Cantidad = cantidad;
        }

        public override string ToString()
        {
            return "Id producto: " + CodigoProducto + "\n" +
                "Nombre producto: " + NombreProducto + "\n" +
                "Precio producto: " + PrecioProducto + "\n" +
                "Stock disponible: " + Cantidad;
        }
    }
}
