﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class Producto
    {
        private int idProducto;
        private string nombreProducto;
        private double precioProducto;
        private int stockProducto;

        public Producto(int idProducto, string nombreProducto, double precioProducto, int stockProducto)
        {
            this.idProducto = idProducto;
            this.nombreProducto = nombreProducto;
            this.precioProducto = precioProducto;
            this.stockProducto = stockProducto;
        }

        public int getIdProducto()
        {
            return idProducto;
        }

        public void setIdProducto(int idProducto)
        {
            this.idProducto = idProducto;
        }

        public string getNombreProducto()
        {
            return nombreProducto;
        }

        public void setNombreProducto(string nombreProducto)
        {
            this.nombreProducto = nombreProducto;
        }

        public double getPrecioProducto()
        {
            return precioProducto;
        }

        public void setPrecioProducto(double precioProducto)
        {
            this.precioProducto = precioProducto;
        }

        public int getStockProducto()
        {
            return stockProducto;
        }

        public void setStockProducto(int stockProducto)
        {
            this.stockProducto = stockProducto;
        }

        public override string ToString()
        {
            return "Id producto: " + idProducto + "\n" +
                "Nombre producto: " + nombreProducto + "\n" +
                "Precio producto: " + precioProducto + "\n" +
                "Stock disponible: " + stockProducto;
        }
    }
}
