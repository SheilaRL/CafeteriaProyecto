﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class InicioEmpleado : Form
    {
        public InicioEmpleado()
        {
            InitializeComponent();
        }

        public void anyadirContoles(Form f)
        {
            panel3Empleado.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel3Empleado.Controls.Add(f);
            f.Show();
        }

        private void InicioEmpleado_Load(object sender, EventArgs e)
        {

        }

        private void botonSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1Cuenta_Click(object sender, EventArgs e)
        {
            anyadirContoles(new Cuenta());
        }

        private void button2Reservas_Click(object sender, EventArgs e)
        {
            anyadirContoles(new mesasOpcion());
        }

        private void button7Pedidos_Click(object sender, EventArgs e)
        {
            anyadirContoles(new Pedidos());
        }
    }
}
