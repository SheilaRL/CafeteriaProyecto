﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class Dulce : Producto
    {
        private int codigoDulce;
        private string nombreDulce;
        private double precioDulce;
        private int stockDulce;
        private string tipoDulce;

        public Dulce(string codigoProducto, string nombreProducto, string cantidad, string precioProducto) :
            base(codigoProducto, nombreProducto, cantidad, precioProducto)
        {
        }

        public int getCodigoDulce()
        {
            return codigoDulce;
        }

        public void setCodigoDulce(int codigoDulce)
        {
            this.codigoDulce = codigoDulce;
        }

        public string getNombreDulce()
        {
            return nombreDulce;
        }

        public void setNombreDulce(string nombreDulce)
        {
            this.nombreDulce = nombreDulce;
        }

        public double getPrecioDulce()
        {
            return precioDulce;
        }

        public void setPrecioDulce(double precioDulce)
        {
            this.precioDulce = precioDulce;
        }

        public int getStockDulce()
        {
            return stockDulce;
        }

        public void setStockDulce(int stockDulce)
        {
            this.stockDulce = stockDulce;
        }

        public string getTipoDulce()
        {
            return tipoDulce;
        }

        public void setTipoDulce(string tipoDulce)
        {
            this.tipoDulce = tipoDulce;
        }
    }
}
