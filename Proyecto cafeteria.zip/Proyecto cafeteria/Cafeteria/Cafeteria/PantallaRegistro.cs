﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class PantallaRegistro : Form
    {
        InicioSesion inicioSesionRegistro;
        private ListaUsuarios listaUsuarios;

        public PantallaRegistro()
        {
            InitializeComponent();
            inicioSesionRegistro = new InicioSesion();
            listaUsuarios = new ListaUsuarios();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void apellidoRegistro_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox3Registro_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4Registro_Click(object sender, EventArgs e)
        {

        }

        private void textBox4Registro_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5Registro_Click(object sender, EventArgs e)
        {

        }

        private void textBox5Registro_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2Registro_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1Registro_Click(object sender, EventArgs e)
        {
            inicioSesionRegistro.ShowDialog();
            string nombre, apellido, email, contrasenya, direccion;
            int numeroTelef;

            nombre = textBox1Registro.Text;
            apellido = textBox2Registro.Text;
            email = textBox3Registro.Text;
            contrasenya = textBox6Contraseña.Text;
            direccion = textBox5Registro.Text;
            numeroTelef = Convert.ToInt32(textBox4Registro.Text);

            if (radioButton1Registro.Checked)
            {
                 listaUsuarios.anyadirUsuarios(new Cliente(nombre, apellido, email, contrasenya, numeroTelef, direccion));
            }

            else if (radioButton2Registro.Checked)
            {
                listaUsuarios.anyadirUsuarios(new Empleado(nombre, apellido, email, contrasenya, numeroTelef, direccion));
            }

           
        }

        private void label6Contraseña_Click(object sender, EventArgs e)
        {

        }

        private void PantallaRegistro_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
