﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class PantallaRegistro : Form
    {
        //InicioSesion inicioSesionRegistro;

        private ListaUsuarios listaUsuarios;

        public PantallaRegistro(ListaUsuarios listaUsuarios)
        {
            InitializeComponent();
            //inicioSesionRegistro = new InicioSesion(listaUsuarios);
            this.listaUsuarios = listaUsuarios;
            //listaUsuarios.cargarUsuarios();

        }

        public ListaUsuarios ListasUsuariosRegistrados { get => listaUsuarios; set => listaUsuarios = value; }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void apellidoRegistro_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox3Registro_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4Registro_Click(object sender, EventArgs e)
        {

        }

        private void textBox4Registro_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5Registro_Click(object sender, EventArgs e)
        {

        }

        private void textBox5Registro_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2Registro_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1Registro_Click(object sender, EventArgs e)
        {
            string nombre = textBox1Registro.Text;
            string apellido = textBox2Registro.Text;
            string correo = textBox3Registro.Text;
            string contrasenya = textBox6Contraseña.Text;
            string numeroTelef = textBox4Registro.Text;
            string direccion = textBox5Registro.Text;
            bool esCliente = radioButton1Registro.Checked;
            bool esEmpleado = radioButton2Registro.Checked;

            if (string.IsNullOrEmpty(nombre) ||
               string.IsNullOrEmpty(apellido) ||
               string.IsNullOrEmpty(correo) ||
               string.IsNullOrEmpty(contrasenya) ||
               string.IsNullOrEmpty(numeroTelef) ||
               string.IsNullOrEmpty(direccion))
            {
                MessageBox.Show("Por favor, complete todos los campos");
            }

            Usuario nuevoUsuario = new Usuario(nombre, apellido, correo, contrasenya, numeroTelef, direccion, esCliente, esEmpleado);

            if (!listaUsuarios.getListaUsuarios().Any(l => l.Nombre == nombre))
            {
                listaUsuarios.anyadirUsuarios(nuevoUsuario);
                MessageBox.Show("Registro finalizado");
            }

            else
            {
                MessageBox.Show("El usuario ya existe");
            }

            //listaUsuarios.anyadirUsuarios(nuevoUsuario);

            //LimpiarCampos();

            this.Close();
           
        }

        private void LimpiarCampos()
        {
            textBox1Registro.Text = "";
            textBox2Registro.Text = "";
            textBox3Registro.Text = "";
            textBox4Registro.Text = "";
            textBox5Registro.Text = "";
            textBox6Contraseña.Text = "";
            radioButton1Registro.Checked = false;
            radioButton2Registro.Checked = false;
        }


        private void guardarUsuario(Usuario usuario)
        { 
            try
            {
                using (StreamWriter misUsuarios = new StreamWriter("usuarios.txt", true))
                {
                    MessageBox.Show(usuario.ToString());
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Error al registrar");
            }
        }

        private void label6Contraseña_Click(object sender, EventArgs e)
        {

        }

        private void PantallaRegistro_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1Registro.Clear();
            textBox2Registro.Clear();
            textBox3Registro.Clear();
            textBox4Registro.Clear();
            textBox5Registro.Clear();
            textBox6Contraseña.Clear();
        }
    }
}
