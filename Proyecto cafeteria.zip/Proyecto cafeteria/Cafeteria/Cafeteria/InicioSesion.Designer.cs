﻿namespace Cafeteria
{
    partial class InicioSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabel1IncioSesion = new System.Windows.Forms.LinkLabel();
            this.boton1InicioSesion = new System.Windows.Forms.Button();
            this.textBox2InicioSesion = new System.Windows.Forms.TextBox();
            this.label3InicioSesion = new System.Windows.Forms.Label();
            this.textBox1InicioSesion = new System.Windows.Forms.TextBox();
            this.label2InicioSesion = new System.Windows.Forms.Label();
            this.label1InicioSesion = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.radioButton2);
            this.panel1.Controls.Add(this.radioButton1);
            this.panel1.Controls.Add(this.linkLabel1IncioSesion);
            this.panel1.Controls.Add(this.boton1InicioSesion);
            this.panel1.Controls.Add(this.textBox2InicioSesion);
            this.panel1.Controls.Add(this.label3InicioSesion);
            this.panel1.Controls.Add(this.textBox1InicioSesion);
            this.panel1.Controls.Add(this.label2InicioSesion);
            this.panel1.Controls.Add(this.label1InicioSesion);
            this.panel1.Location = new System.Drawing.Point(56, 87);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(413, 370);
            this.panel1.TabIndex = 0;
            // 
            // linkLabel1IncioSesion
            // 
            this.linkLabel1IncioSesion.ActiveLinkColor = System.Drawing.Color.Black;
            this.linkLabel1IncioSesion.AutoSize = true;
            this.linkLabel1IncioSesion.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1IncioSesion.LinkColor = System.Drawing.Color.White;
            this.linkLabel1IncioSesion.Location = new System.Drawing.Point(137, 321);
            this.linkLabel1IncioSesion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel1IncioSesion.Name = "linkLabel1IncioSesion";
            this.linkLabel1IncioSesion.Size = new System.Drawing.Size(138, 14);
            this.linkLabel1IncioSesion.TabIndex = 6;
            this.linkLabel1IncioSesion.TabStop = true;
            this.linkLabel1IncioSesion.Text = "Contraseña olvidada";
            this.linkLabel1IncioSesion.VisitedLinkColor = System.Drawing.Color.Red;
            // 
            // boton1InicioSesion
            // 
            this.boton1InicioSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton1InicioSesion.Location = new System.Drawing.Point(137, 266);
            this.boton1InicioSesion.Margin = new System.Windows.Forms.Padding(4);
            this.boton1InicioSesion.Name = "boton1InicioSesion";
            this.boton1InicioSesion.Size = new System.Drawing.Size(144, 37);
            this.boton1InicioSesion.TabIndex = 5;
            this.boton1InicioSesion.Text = "Entrar";
            this.boton1InicioSesion.UseVisualStyleBackColor = true;
            this.boton1InicioSesion.Click += new System.EventHandler(this.boton1InicioSesion_Click);
            // 
            // textBox2InicioSesion
            // 
            this.textBox2InicioSesion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2InicioSesion.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2InicioSesion.Location = new System.Drawing.Point(37, 178);
            this.textBox2InicioSesion.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2InicioSesion.Name = "textBox2InicioSesion";
            this.textBox2InicioSesion.Size = new System.Drawing.Size(313, 24);
            this.textBox2InicioSesion.TabIndex = 4;
            // 
            // label3InicioSesion
            // 
            this.label3InicioSesion.AutoSize = true;
            this.label3InicioSesion.BackColor = System.Drawing.Color.Teal;
            this.label3InicioSesion.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3InicioSesion.ForeColor = System.Drawing.Color.White;
            this.label3InicioSesion.Location = new System.Drawing.Point(33, 144);
            this.label3InicioSesion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3InicioSesion.Name = "label3InicioSesion";
            this.label3InicioSesion.Size = new System.Drawing.Size(116, 20);
            this.label3InicioSesion.TabIndex = 3;
            this.label3InicioSesion.Text = "Contraseña";
            // 
            // textBox1InicioSesion
            // 
            this.textBox1InicioSesion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1InicioSesion.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1InicioSesion.Location = new System.Drawing.Point(37, 96);
            this.textBox1InicioSesion.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1InicioSesion.Name = "textBox1InicioSesion";
            this.textBox1InicioSesion.Size = new System.Drawing.Size(313, 24);
            this.textBox1InicioSesion.TabIndex = 2;
            // 
            // label2InicioSesion
            // 
            this.label2InicioSesion.AutoSize = true;
            this.label2InicioSesion.BackColor = System.Drawing.Color.Teal;
            this.label2InicioSesion.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2InicioSesion.ForeColor = System.Drawing.Color.White;
            this.label2InicioSesion.Location = new System.Drawing.Point(33, 72);
            this.label2InicioSesion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2InicioSesion.Name = "label2InicioSesion";
            this.label2InicioSesion.Size = new System.Drawing.Size(84, 20);
            this.label2InicioSesion.TabIndex = 1;
            this.label2InicioSesion.Text = "Nombre";
            // 
            // label1InicioSesion
            // 
            this.label1InicioSesion.AutoSize = true;
            this.label1InicioSesion.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1InicioSesion.ForeColor = System.Drawing.Color.White;
            this.label1InicioSesion.Location = new System.Drawing.Point(133, 21);
            this.label1InicioSesion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1InicioSesion.Name = "label1InicioSesion";
            this.label1InicioSesion.Size = new System.Drawing.Size(151, 23);
            this.label1InicioSesion.TabIndex = 0;
            this.label1InicioSesion.Text = "Inicio Sesión";
            this.label1InicioSesion.Click += new System.EventHandler(this.label1InicioSesion_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Cafeteria.Properties.Resources.ab243b121096839_60bf1f47aef05;
            this.pictureBox1.Location = new System.Drawing.Point(265, 74);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(868, 384);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.ForeColor = System.Drawing.Color.White;
            this.radioButton1.Location = new System.Drawing.Point(37, 225);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(131, 20);
            this.radioButton1.TabIndex = 7;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Soy empleado";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.ForeColor = System.Drawing.Color.White;
            this.radioButton2.Location = new System.Drawing.Point(219, 225);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(108, 20);
            this.radioButton2.TabIndex = 8;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Soy cliente";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // InicioSesion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(940, 554);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "InicioSesion";
            this.Text = "InicioSesion";
            this.Load += new System.EventHandler(this.InicioSesion_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1InicioSesion;
        private System.Windows.Forms.Label label2InicioSesion;
        private System.Windows.Forms.Label label3InicioSesion;
        private System.Windows.Forms.TextBox textBox1InicioSesion;
        private System.Windows.Forms.TextBox textBox2InicioSesion;
        private System.Windows.Forms.LinkLabel linkLabel1IncioSesion;
        private System.Windows.Forms.Button boton1InicioSesion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}