﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    internal class Empleado : Usuario
    {
        private int codigoEmpleado;

        public Empleado(string nombre, string apellido, string correo, string contrasenya, int numeroTelef, string direccion) :
            base()
        {
            
        }

        public int getCodigoEmpleado()
        {
            return codigoEmpleado;
        }

        public void setCodigoEmpleado(int codigoEmpleado)
        {
            this.codigoEmpleado = codigoEmpleado;
        }

        public override string ToString()
        {
            return base.ToString() + codigoEmpleado;
        }

    }
}
