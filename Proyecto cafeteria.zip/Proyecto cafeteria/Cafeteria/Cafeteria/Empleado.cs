﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class Empleado : Usuario
    {
        public Empleado(string nombre, string apellido, string correo, string contrasenya, string numeroTelef,
            string direccion, bool esCliente, bool esEmpleado) : base(nombre, apellido, correo, contrasenya, numeroTelef, 
                direccion, esCliente, esEmpleado)
        {
        }

        public override string ToString()
        {
            return base.ToString();
        }

    }
}
