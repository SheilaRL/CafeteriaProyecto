﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class InicioSesion : Form
    {
        InicioEmpleado inicioEmpleado;
        private ListaUsuarios listaUsuarios;
        private string usuarioCliente = "cliente";
        private string contrasenyaCliente = "1234";
        private string usuarioEmpleado = "empleado";
        private string contrasenyaEmpleado = "contrasenyaEmpleado";
  

        public InicioSesion()
        {
            InitializeComponent();
            inicioEmpleado = new InicioEmpleado(); 
            listaUsuarios = new ListaUsuarios();
          
        }

        private void label1InicioSesion_Click(object sender, EventArgs e)
        {

        }

        private void InicioSesion_Load(object sender, EventArgs e)
        {

        }

        private void boton1InicioSesion_Click(object sender, EventArgs e)
        {
            string nombreUsuario = textBox1InicioSesion.Text;
            string contrasenya = textBox2InicioSesion.Text;
            bool esCliente = radioButton2.Checked;
            bool esEmpleado = radioButton1.Checked;

            if (esCliente)
            {
                if (nombreUsuario == usuarioCliente && contrasenya == contrasenyaCliente)
                {
                    MessageBox.Show("Bienvenido" + usuarioCliente);
                }

                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos, por favor, inténtelo otra vez");
                }
            }

            else
            {
                if (nombreUsuario == usuarioEmpleado && contrasenya == contrasenyaEmpleado)
                {
                    MessageBox.Show("Bienvenido " + usuarioEmpleado);
                    inicioEmpleado.ShowDialog();
                }

                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos, por favor, inténtelo otra vez");
                }
            }



        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
