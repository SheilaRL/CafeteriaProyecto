﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class InicioSesion : Form
    {
        InicioEmpleado inicioEmpleado;
        public InicioSesion()
        {
            InitializeComponent();
            inicioEmpleado = new InicioEmpleado();
          
        }

        private void label1InicioSesion_Click(object sender, EventArgs e)
        {

        }

        private void InicioSesion_Load(object sender, EventArgs e)
        {

        }

        private void boton1InicioSesion_Click(object sender, EventArgs e)
        {
            inicioEmpleado.ShowDialog();
        }
    }
}
