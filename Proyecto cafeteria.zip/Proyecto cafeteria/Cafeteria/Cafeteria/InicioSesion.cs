﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class InicioSesion : Form
    {
        InicioEmpleado inicioEmpleado;
        panelCliente inicioCliente;
        private ListaUsuarios listaUsuarios;

        public ListaUsuarios ListaUsuarios { get => listaUsuarios; set => listaUsuarios = value; }

        /*private string usuarioCliente = "cliente";
        private string contrasenyaCliente = "1234";
        private string usuarioEmpleado = "empleado";
        private string contrasenyaEmpleado = "contrasenyaEmpleado";*/


        public InicioSesion(ListaUsuarios listaUsuarios)
        {
            InitializeComponent();
            inicioEmpleado = new InicioEmpleado(); 
            inicioCliente = new panelCliente();
            this.listaUsuarios = listaUsuarios;
          
        }

        private void label1InicioSesion_Click(object sender, EventArgs e)
        {

        }

        private void InicioSesion_Load(object sender, EventArgs e)
        {

        }

        private void boton1InicioSesion_Click(object sender, EventArgs e)
        {
            string nombre = textBox1InicioSesion.Text;
            string contrasenya = textBox2InicioSesion.Text;
            bool esCliente = radioButton2.Checked;
            bool esEmpleado = radioButton1.Checked;

            Usuario usuario = listaUsuarios.iniciarSesion(nombre, contrasenya);

            if (usuario != null)
            {
                if (esCliente && usuario.EsCliente)
                {
                    MessageBox.Show("Iniciando sesión, bienvenido " + usuario.EsCliente);
                    this.Close();
                    inicioCliente.ShowDialog();
                }

                else if (esEmpleado && usuario.EsEmpleado)
                {
                    MessageBox.Show("Iniciando sesión, bienvenido " + usuario.EsEmpleado);
                    this.Close();
                    inicioEmpleado.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Error de usuario");
                }
            }

            else
            {
                MessageBox.Show("Nombre de usuario o contraseña incorrectos.");
            }

        }

        private void limpiarCampos()
        {
            textBox1InicioSesion.Text = "";
            textBox2InicioSesion.Text = "";
        }


        public void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox2InicioSesion_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
