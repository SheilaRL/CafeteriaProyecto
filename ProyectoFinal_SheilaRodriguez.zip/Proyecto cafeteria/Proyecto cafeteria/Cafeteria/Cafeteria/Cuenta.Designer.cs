﻿namespace Cafeteria
{
    partial class Cuenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTotal = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.labelCambio = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelDevolver = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.botonPagar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(138, 60);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(152, 22);
            this.labelTotal.TabIndex = 24;
            this.labelTotal.Text = "Cantidad total";
            this.labelTotal.Click += new System.EventHandler(this.labelTotal_Click);
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(138, 116);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(152, 22);
            this.textBox6.TabIndex = 25;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // labelCambio
            // 
            this.labelCambio.AutoSize = true;
            this.labelCambio.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCambio.Location = new System.Drawing.Point(172, 187);
            this.labelCambio.Name = "labelCambio";
            this.labelCambio.Size = new System.Drawing.Size(85, 22);
            this.labelCambio.TabIndex = 26;
            this.labelCambio.Text = "Cambio";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(138, 243);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(152, 22);
            this.textBox1.TabIndex = 27;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // labelDevolver
            // 
            this.labelDevolver.AutoSize = true;
            this.labelDevolver.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDevolver.Location = new System.Drawing.Point(172, 322);
            this.labelDevolver.Name = "labelDevolver";
            this.labelDevolver.Size = new System.Drawing.Size(100, 22);
            this.labelDevolver.TabIndex = 28;
            this.labelDevolver.Text = "Devolver";
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(138, 375);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(152, 22);
            this.textBox2.TabIndex = 29;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // botonPagar
            // 
            this.botonPagar.BackColor = System.Drawing.Color.Teal;
            this.botonPagar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.botonPagar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botonPagar.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonPagar.ForeColor = System.Drawing.Color.White;
            this.botonPagar.Location = new System.Drawing.Point(176, 436);
            this.botonPagar.Name = "botonPagar";
            this.botonPagar.Size = new System.Drawing.Size(82, 42);
            this.botonPagar.TabIndex = 30;
            this.botonPagar.Text = "Pagar";
            this.botonPagar.UseVisualStyleBackColor = false;
            this.botonPagar.Click += new System.EventHandler(this.botonPagar_Click);
            // 
            // Cuenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(433, 511);
            this.Controls.Add(this.botonPagar);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.labelDevolver);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelCambio);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.labelTotal);
            this.Name = "Cuenta";
            this.Text = "Cuenta";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label labelCambio;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelDevolver;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button botonPagar;
    }
}