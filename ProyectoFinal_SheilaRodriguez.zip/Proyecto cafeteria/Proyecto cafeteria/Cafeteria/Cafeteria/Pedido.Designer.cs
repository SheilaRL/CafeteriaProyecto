﻿namespace Cafeteria
{
    partial class Pedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.numeroPedidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mesaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pedidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comandaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1Anyadir = new System.Windows.Forms.Button();
            this.button2Modificar = new System.Windows.Forms.Button();
            this.button3Eliminar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.botonCuenta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comandaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Cafeteria.Properties.Resources.pngtree_perfect_cappuccino_isolated_cartoon_vector_illustrations_picture_image_8710553;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(304, 248);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DarkSlateGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numeroPedidoDataGridViewTextBoxColumn,
            this.mesaDataGridViewTextBoxColumn,
            this.pedidoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.comandaBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(372, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(575, 458);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // numeroPedidoDataGridViewTextBoxColumn
            // 
            this.numeroPedidoDataGridViewTextBoxColumn.DataPropertyName = "NumeroPedido";
            this.numeroPedidoDataGridViewTextBoxColumn.HeaderText = "NumeroPedido";
            this.numeroPedidoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numeroPedidoDataGridViewTextBoxColumn.Name = "numeroPedidoDataGridViewTextBoxColumn";
            this.numeroPedidoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // mesaDataGridViewTextBoxColumn
            // 
            this.mesaDataGridViewTextBoxColumn.DataPropertyName = "Mesa";
            this.mesaDataGridViewTextBoxColumn.HeaderText = "Mesa";
            this.mesaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mesaDataGridViewTextBoxColumn.Name = "mesaDataGridViewTextBoxColumn";
            this.mesaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pedidoDataGridViewTextBoxColumn
            // 
            this.pedidoDataGridViewTextBoxColumn.DataPropertyName = "Pedido";
            this.pedidoDataGridViewTextBoxColumn.HeaderText = "Pedido";
            this.pedidoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pedidoDataGridViewTextBoxColumn.Name = "pedidoDataGridViewTextBoxColumn";
            this.pedidoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // comandaBindingSource
            // 
            this.comandaBindingSource.DataSource = typeof(Cafeteria.Comanda);
            // 
            // button1Anyadir
            // 
            this.button1Anyadir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1Anyadir.Location = new System.Drawing.Point(372, 492);
            this.button1Anyadir.Name = "button1Anyadir";
            this.button1Anyadir.Size = new System.Drawing.Size(89, 36);
            this.button1Anyadir.TabIndex = 12;
            this.button1Anyadir.Text = "Añadir";
            this.button1Anyadir.UseVisualStyleBackColor = true;
            this.button1Anyadir.Click += new System.EventHandler(this.button1Anyadir_Click);
            // 
            // button2Modificar
            // 
            this.button2Modificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2Modificar.Location = new System.Drawing.Point(539, 492);
            this.button2Modificar.Name = "button2Modificar";
            this.button2Modificar.Size = new System.Drawing.Size(89, 36);
            this.button2Modificar.TabIndex = 13;
            this.button2Modificar.Text = "Modificar";
            this.button2Modificar.UseVisualStyleBackColor = true;
            this.button2Modificar.Click += new System.EventHandler(this.button2Modificar_Click);
            // 
            // button3Eliminar
            // 
            this.button3Eliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3Eliminar.Location = new System.Drawing.Point(704, 492);
            this.button3Eliminar.Name = "button3Eliminar";
            this.button3Eliminar.Size = new System.Drawing.Size(89, 36);
            this.button3Eliminar.TabIndex = 14;
            this.button3Eliminar.Text = "Eliminar";
            this.button3Eliminar.UseVisualStyleBackColor = true;
            this.button3Eliminar.Click += new System.EventHandler(this.button3Eliminar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "Número pedido";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(16, 290);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(151, 22);
            this.textBox1.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 331);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Mesa";
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(16, 354);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(151, 22);
            this.textBox2.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 394);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "Pedido";
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(16, 424);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(263, 88);
            this.textBox3.TabIndex = 20;
            // 
            // botonCuenta
            // 
            this.botonCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botonCuenta.Location = new System.Drawing.Point(858, 492);
            this.botonCuenta.Name = "botonCuenta";
            this.botonCuenta.Size = new System.Drawing.Size(89, 36);
            this.botonCuenta.TabIndex = 21;
            this.botonCuenta.Text = "Cuenta";
            this.botonCuenta.UseVisualStyleBackColor = true;
            this.botonCuenta.Click += new System.EventHandler(this.botonCuenta_Click);
            // 
            // Pedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(976, 559);
            this.Controls.Add(this.botonCuenta);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3Eliminar);
            this.Controls.Add(this.button2Modificar);
            this.Controls.Add(this.button1Anyadir);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Pedido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Pedido";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Pedido_FormClosing);
            this.Load += new System.EventHandler(this.Pedido_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comandaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1Anyadir;
        private System.Windows.Forms.Button button2Modificar;
        private System.Windows.Forms.Button button3Eliminar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.BindingSource comandaBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroPedidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mesaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pedidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button botonCuenta;
    }
}