﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class Producto
    {
        private string codigoProducto;
        private string nombreProducto;
        private int cantidad;
        private string precioProducto;

        public string CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string NombreProducto { get => nombreProducto; set => nombreProducto = value; }
        public int Cantidad { get => cantidad; set => cantidad = value; }
        public string PrecioProducto { get => precioProducto; set => precioProducto = value; }

        public Producto(string codigoProducto, string nombreProducto, int cantidad, string precioProducto)
        {
            this.CodigoProducto = codigoProducto;
            this.NombreProducto = nombreProducto;
            this.Cantidad = cantidad;
            this.PrecioProducto = precioProducto;
        }

        public Producto()
        {
        }

        public string getcodigoProducto()
        {
            return CodigoProducto;
        }

        public void setcodigoProducto(string codigoProducto)
        {
            this.CodigoProducto = codigoProducto;
        }

        public string getNombreProducto()
        {
            return NombreProducto;
        }

        public void setNombreProducto(string nombreProducto)
        {
            this.NombreProducto = nombreProducto;
        }

        public string getPrecioProducto()
        {
            return PrecioProducto;
        }

        public void setPrecioProducto(string precioProducto)
        {
            this.PrecioProducto = precioProducto;
        }

        public int getCantidad()
        {
            return Cantidad;
        }

        public void setCantidad(int cantidad)
        {
            this.Cantidad = cantidad;
        }

        public override string ToString()
        {
            return "Id producto: " + CodigoProducto + "\n" +
                "Nombre producto: " + NombreProducto + "\n" +
                "Precio producto: " + PrecioProducto + "\n" +
                "Stock disponible: " + Cantidad;
        }
    }
}
