﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class panelCliente : Form
    {
        private string ruta = "compras.txt";

        public panelCliente()
        {
            InitializeComponent();
            datagridview();
            cargarProductos();
        }

        public void anyadirContoles(Form f)
        {
            panel2Cliente.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel2Cliente.Controls.Add(f);
            f.Show();
        }

        private void InicioCliente_Load(object sender, EventArgs e)
        {

        }

        private void panel2Cliente_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1Logo_Click(object sender, EventArgs e)
        {

        }

        private void button1Cuenta_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(label13.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    MessageBox.Show("Por favor, selecciona todos los campos.");
                }

                if (!double.TryParse(textBox4.Text, out double cantidad))
                {
                    MessageBox.Show("Precio no válido");
                }

                if (!double.TryParse(label13.Text.Replace("€", ""), out double precio))
                {
                    MessageBox.Show("Cantidad no válida");
                }

                DataGridViewRow fila = new DataGridViewRow();
                fila.CreateCells(dataGridView1);

                fila.Cells[0].Value = cantidad;
                fila.Cells[1].Value = precio;
                fila.Cells[2].Value = label2.Text;
                fila.Cells[3].Value = (precio * cantidad).ToString("0.00");

                dataGridView1.Rows.Add(fila);
                label13.Text = textBox4.Text = label2.Text = string.Empty;
                sacarTotal();
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            double precio = 0;
            string nombre = comboProductos.SelectedItem.ToString();

            switch (nombre)
            {
                case "Café con leche":
                    precio = 1.20;
                    break;
                case "Café Latte":
                    precio = 1.50;
                    break;
                case "Café Espresso":
                    precio = 1.30;
                    break;
                case "Café Americano":
                    precio = 1.40;
                    break;
                case "Capuccino":
                    precio = 2.00;
                    break;
                case "Tostada con tomate":
                    precio = 2.00;
                    break;
                case "Tostada con salmón":
                    precio = 2.50; ;
                    break;
                case "Tostada con aguacate":
                    precio = 2.30;
                    break;
                case "Tortitas":
                    precio = 2.00;
                    break;
                case "Tortitas con chocolate":
                    precio = 2.30;
                    break;
                case "Tortitas con nata y plátano":
                    precio = 3.00;
                    break;
            }

            label2.Text = nombre;
            label13.Text = precio.ToString("0.00") +  "€";
        }


        public void sacarTotal()
        {
            double totalPedido = 0;

            foreach (DataGridViewRow fila in dataGridView1.Rows)
            {
                if (fila.Cells[3].Value != null && !string.IsNullOrWhiteSpace(fila.Cells[3].Value.ToString()));
                {
                    if (double.TryParse(fila.Cells[3].Value.ToString(), out double subtotal))
                    {
                        totalPedido += subtotal;
                    }
                }
            }

            label8.Text = totalPedido.ToString("0.00");
           
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                DialogResult eliminar = MessageBox.Show("Estás seguro que deseas eliminar?",
                    "Eliminado", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (eliminar == DialogResult.Yes)
                {
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Error al eliminar.");
            }

            sacarTotal();
        }

        private void datagridview()
        {
            dataGridView1.Columns.Clear();

            dataGridView1.Columns.Add("Cantidad", "Cantidad");
            dataGridView1.Columns.Add("Precio", "Precio");
            dataGridView1.Columns.Add("Producto", "Producto");
            dataGridView1.Columns.Add("Subtotal", "Subtotal");

            dataGridView1.Columns["Cantidad"].ValueType = typeof(double);
            dataGridView1.Columns["Precio"].ValueType = typeof(double);
            dataGridView1.Columns["Subtotal"].ValueType = typeof(double);

            dataGridView1.AllowUserToAddRows = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Gracias por su compra. En breves recibirá un correo con el seguimiento del pedido");
        }

        private void cargarProductos()
        {
            try
            {
                if (!File.Exists(ruta))
                {
                    MessageBox.Show("El archivo no existe");
                }

                string[] productos = File.ReadAllLines(ruta);


                if (productos.Length == 0)
                {
                    MessageBox.Show("El fichero está vacio");
                }

                comboProductos.Items.Clear();

                foreach (string producto in productos)
                {
                    comboProductos.Items.Add(producto);
                }

                if (comboProductos.Items.Count > 0)
                {
                    comboProductos.SelectedIndex = 0;
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Error al cargar los productos");
            }
        }

        private void guardarProductos(string[] productos)
        {
            try
            {
                File.WriteAllLines(ruta, productos);
            }
            catch (Exception)
            {
                MessageBox.Show("Error al guardar los productos");
            }
        }
    }
}
