﻿namespace Cafeteria
{
    partial class PantallaInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tituloInicio = new System.Windows.Forms.Label();
            this.fotoCafeInicio = new System.Windows.Forms.PictureBox();
            this.botonInicioSesion = new System.Windows.Forms.Button();
            this.boton2Registro = new System.Windows.Forms.Button();
            this.dibujoPantallaInicio = new System.Windows.Forms.Panel();
            this.panel2PantallaInicio = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.fotoCafeInicio)).BeginInit();
            this.SuspendLayout();
            // 
            // tituloInicio
            // 
            this.tituloInicio.AutoSize = true;
            this.tituloInicio.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tituloInicio.ForeColor = System.Drawing.Color.White;
            this.tituloInicio.Location = new System.Drawing.Point(289, 428);
            this.tituloInicio.Name = "tituloInicio";
            this.tituloInicio.Size = new System.Drawing.Size(348, 57);
            this.tituloInicio.TabIndex = 1;
            this.tituloInicio.Text = "Vita con caffé";
            this.tituloInicio.Click += new System.EventHandler(this.label1_Click);
            // 
            // fotoCafeInicio
            // 
            this.fotoCafeInicio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.fotoCafeInicio.Image = global::Cafeteria.Properties.Resources.b2da1fccadfed726bc47caa8b5c71499_removebg_preview;
            this.fotoCafeInicio.Location = new System.Drawing.Point(231, 60);
            this.fotoCafeInicio.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fotoCafeInicio.Name = "fotoCafeInicio";
            this.fotoCafeInicio.Size = new System.Drawing.Size(485, 423);
            this.fotoCafeInicio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fotoCafeInicio.TabIndex = 0;
            this.fotoCafeInicio.TabStop = false;
            this.fotoCafeInicio.Click += new System.EventHandler(this.fotoCafeInicio_Click);
            // 
            // botonInicioSesion
            // 
            this.botonInicioSesion.BackColor = System.Drawing.Color.Teal;
            this.botonInicioSesion.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonInicioSesion.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.botonInicioSesion.Location = new System.Drawing.Point(596, 14);
            this.botonInicioSesion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.botonInicioSesion.Name = "botonInicioSesion";
            this.botonInicioSesion.Size = new System.Drawing.Size(139, 43);
            this.botonInicioSesion.TabIndex = 2;
            this.botonInicioSesion.Text = "Inicio Sesión";
            this.botonInicioSesion.UseVisualStyleBackColor = false;
            this.botonInicioSesion.Click += new System.EventHandler(this.button1_Click);
            // 
            // boton2Registro
            // 
            this.boton2Registro.BackColor = System.Drawing.Color.DarkCyan;
            this.boton2Registro.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton2Registro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.boton2Registro.Location = new System.Drawing.Point(768, 14);
            this.boton2Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.boton2Registro.Name = "boton2Registro";
            this.boton2Registro.Size = new System.Drawing.Size(137, 43);
            this.boton2Registro.TabIndex = 3;
            this.boton2Registro.Text = "Registrarse";
            this.boton2Registro.UseVisualStyleBackColor = false;
            this.boton2Registro.Click += new System.EventHandler(this.boton2Registro_Click);
            // 
            // dibujoPantallaInicio
            // 
            this.dibujoPantallaInicio.BackColor = System.Drawing.Color.White;
            this.dibujoPantallaInicio.Location = new System.Drawing.Point(3, 459);
            this.dibujoPantallaInicio.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dibujoPantallaInicio.Name = "dibujoPantallaInicio";
            this.dibujoPantallaInicio.Size = new System.Drawing.Size(284, 12);
            this.dibujoPantallaInicio.TabIndex = 4;
            // 
            // panel2PantallaInicio
            // 
            this.panel2PantallaInicio.BackColor = System.Drawing.Color.White;
            this.panel2PantallaInicio.Location = new System.Drawing.Point(645, 459);
            this.panel2PantallaInicio.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2PantallaInicio.Name = "panel2PantallaInicio";
            this.panel2PantallaInicio.Size = new System.Drawing.Size(295, 12);
            this.panel2PantallaInicio.TabIndex = 5;
            // 
            // PantallaInicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(941, 561);
            this.Controls.Add(this.panel2PantallaInicio);
            this.Controls.Add(this.dibujoPantallaInicio);
            this.Controls.Add(this.boton2Registro);
            this.Controls.Add(this.botonInicioSesion);
            this.Controls.Add(this.tituloInicio);
            this.Controls.Add(this.fotoCafeInicio);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "PantallaInicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vita con caffé";
            this.Load += new System.EventHandler(this.PantallaInicio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fotoCafeInicio)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox fotoCafeInicio;
        private System.Windows.Forms.Label tituloInicio;
        private System.Windows.Forms.Button botonInicioSesion;
        private System.Windows.Forms.Button boton2Registro;
        private System.Windows.Forms.Panel dibujoPantallaInicio;
        private System.Windows.Forms.Panel panel2PantallaInicio;
    }
}