﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class ReservaMesa
    {
        private string nombre;
        private string horaReserva;
        private string fechaReserva;
        private string numeroComensales;
        private string numeroTelefono;

        public ReservaMesa()
        {
        }

        public ReservaMesa(string nombre, string horaReserva, string fechaReserva, string numeroComensales, string numeroTelefono)
        {
            this.Nombre = nombre;
            this.HoraReserva = horaReserva;
            this.FechaReserva = fechaReserva;
            this.NumeroComensales = numeroComensales;
            this.NumeroTelefono = numeroTelefono;
        }

        public string Nombre { get => nombre; set => nombre = value; }
        public string HoraReserva { get => horaReserva; set => horaReserva = value; }
        public string FechaReserva { get => fechaReserva; set => fechaReserva = value; }
        public string NumeroComensales { get => numeroComensales; set => numeroComensales = value; }
        public string NumeroTelefono { get => numeroTelefono; set => numeroTelefono = value; }

        public override string ToString()
        {
            return Nombre + HoraReserva + FechaReserva + NumeroComensales + NumeroTelefono;
        }
    }
}
