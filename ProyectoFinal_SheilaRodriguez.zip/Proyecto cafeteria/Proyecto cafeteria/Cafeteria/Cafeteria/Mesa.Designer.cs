﻿namespace Cafeteria
{
    partial class Mesa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2Mesas = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3Nombre = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.horaReservaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaReservaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroComensalesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroTelefonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reservaMesaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5Personas = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label7Fecha = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4Hora = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6Numero = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button1Anyadir = new System.Windows.Forms.Button();
            this.button2Eliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservaMesaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label2Mesas
            // 
            this.label2Mesas.AutoSize = true;
            this.label2Mesas.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2Mesas.Location = new System.Drawing.Point(31, 18);
            this.label2Mesas.Name = "label2Mesas";
            this.label2Mesas.Size = new System.Drawing.Size(73, 22);
            this.label2Mesas.TabIndex = 3;
            this.label2Mesas.Text = "Mesas";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Location = new System.Drawing.Point(3, 66);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(852, 12);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(586, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Buscar mesa...";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox1.Location = new System.Drawing.Point(589, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(205, 26);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3Nombre
            // 
            this.label3Nombre.AutoSize = true;
            this.label3Nombre.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3Nombre.Location = new System.Drawing.Point(45, 111);
            this.label3Nombre.Name = "label3Nombre";
            this.label3Nombre.Size = new System.Drawing.Size(73, 18);
            this.label3Nombre.TabIndex = 8;
            this.label3Nombre.Text = "Nombre";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.Teal;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nombreDataGridViewTextBoxColumn,
            this.horaReservaDataGridViewTextBoxColumn,
            this.fechaReservaDataGridViewTextBoxColumn,
            this.numeroComensalesDataGridViewTextBoxColumn,
            this.numeroTelefonoDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.reservaMesaBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(81, 235);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(677, 277);
            this.dataGridView2.TabIndex = 19;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            this.nombreDataGridViewTextBoxColumn.ReadOnly = true;
            this.nombreDataGridViewTextBoxColumn.Width = 125;
            // 
            // horaReservaDataGridViewTextBoxColumn
            // 
            this.horaReservaDataGridViewTextBoxColumn.DataPropertyName = "HoraReserva";
            this.horaReservaDataGridViewTextBoxColumn.HeaderText = "HoraReserva";
            this.horaReservaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.horaReservaDataGridViewTextBoxColumn.Name = "horaReservaDataGridViewTextBoxColumn";
            this.horaReservaDataGridViewTextBoxColumn.ReadOnly = true;
            this.horaReservaDataGridViewTextBoxColumn.Width = 125;
            // 
            // fechaReservaDataGridViewTextBoxColumn
            // 
            this.fechaReservaDataGridViewTextBoxColumn.DataPropertyName = "FechaReserva";
            this.fechaReservaDataGridViewTextBoxColumn.HeaderText = "FechaReserva";
            this.fechaReservaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.fechaReservaDataGridViewTextBoxColumn.Name = "fechaReservaDataGridViewTextBoxColumn";
            this.fechaReservaDataGridViewTextBoxColumn.ReadOnly = true;
            this.fechaReservaDataGridViewTextBoxColumn.Width = 125;
            // 
            // numeroComensalesDataGridViewTextBoxColumn
            // 
            this.numeroComensalesDataGridViewTextBoxColumn.DataPropertyName = "NumeroComensales";
            this.numeroComensalesDataGridViewTextBoxColumn.HeaderText = "NumeroComensales";
            this.numeroComensalesDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numeroComensalesDataGridViewTextBoxColumn.Name = "numeroComensalesDataGridViewTextBoxColumn";
            this.numeroComensalesDataGridViewTextBoxColumn.ReadOnly = true;
            this.numeroComensalesDataGridViewTextBoxColumn.Width = 125;
            // 
            // numeroTelefonoDataGridViewTextBoxColumn
            // 
            this.numeroTelefonoDataGridViewTextBoxColumn.DataPropertyName = "NumeroTelefono";
            this.numeroTelefonoDataGridViewTextBoxColumn.HeaderText = "NumeroTelefono";
            this.numeroTelefonoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numeroTelefonoDataGridViewTextBoxColumn.Name = "numeroTelefonoDataGridViewTextBoxColumn";
            this.numeroTelefonoDataGridViewTextBoxColumn.ReadOnly = true;
            this.numeroTelefonoDataGridViewTextBoxColumn.Width = 125;
            // 
            // reservaMesaBindingSource
            // 
            this.reservaMesaBindingSource.DataSource = typeof(Cafeteria.ReservaMesa);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(48, 132);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(152, 22);
            this.textBox2.TabIndex = 20;
            // 
            // label5Personas
            // 
            this.label5Personas.AutoSize = true;
            this.label5Personas.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5Personas.Location = new System.Drawing.Point(300, 111);
            this.label5Personas.Name = "label5Personas";
            this.label5Personas.Size = new System.Drawing.Size(153, 18);
            this.label5Personas.TabIndex = 21;
            this.label5Personas.Text = "Número personas";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(303, 132);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(152, 22);
            this.textBox6.TabIndex = 22;
            // 
            // label7Fecha
            // 
            this.label7Fecha.AutoSize = true;
            this.label7Fecha.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7Fecha.Location = new System.Drawing.Point(553, 111);
            this.label7Fecha.Name = "label7Fecha";
            this.label7Fecha.Size = new System.Drawing.Size(124, 18);
            this.label7Fecha.TabIndex = 23;
            this.label7Fecha.Text = "Fecha reserva";
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Location = new System.Drawing.Point(556, 132);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(152, 22);
            this.textBox5.TabIndex = 24;
            // 
            // label4Hora
            // 
            this.label4Hora.AutoSize = true;
            this.label4Hora.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4Hora.Location = new System.Drawing.Point(45, 171);
            this.label4Hora.Name = "label4Hora";
            this.label4Hora.Size = new System.Drawing.Size(115, 18);
            this.label4Hora.TabIndex = 25;
            this.label4Hora.Text = "Hora reserva";
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(48, 192);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(152, 22);
            this.textBox3.TabIndex = 26;
            // 
            // label6Numero
            // 
            this.label6Numero.AutoSize = true;
            this.label6Numero.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6Numero.Location = new System.Drawing.Point(300, 171);
            this.label6Numero.Name = "label6Numero";
            this.label6Numero.Size = new System.Drawing.Size(145, 18);
            this.label6Numero.TabIndex = 27;
            this.label6Numero.Text = "Número teléfono";
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Location = new System.Drawing.Point(303, 192);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(152, 22);
            this.textBox4.TabIndex = 28;
            // 
            // button1Anyadir
            // 
            this.button1Anyadir.BackColor = System.Drawing.Color.Teal;
            this.button1Anyadir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1Anyadir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1Anyadir.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1Anyadir.ForeColor = System.Drawing.Color.White;
            this.button1Anyadir.Location = new System.Drawing.Point(534, 181);
            this.button1Anyadir.Name = "button1Anyadir";
            this.button1Anyadir.Size = new System.Drawing.Size(82, 42);
            this.button1Anyadir.TabIndex = 29;
            this.button1Anyadir.Text = "Añadir ";
            this.button1Anyadir.UseVisualStyleBackColor = false;
            this.button1Anyadir.Click += new System.EventHandler(this.button1Anyadir_Click);
            // 
            // button2Eliminar
            // 
            this.button2Eliminar.BackColor = System.Drawing.Color.Teal;
            this.button2Eliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2Eliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2Eliminar.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2Eliminar.ForeColor = System.Drawing.Color.White;
            this.button2Eliminar.Location = new System.Drawing.Point(653, 181);
            this.button2Eliminar.Name = "button2Eliminar";
            this.button2Eliminar.Size = new System.Drawing.Size(82, 42);
            this.button2Eliminar.TabIndex = 30;
            this.button2Eliminar.Text = "Eliminar";
            this.button2Eliminar.UseVisualStyleBackColor = false;
            this.button2Eliminar.Click += new System.EventHandler(this.button2Eliminar_Click);
            // 
            // Mesa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(842, 524);
            this.Controls.Add(this.button2Eliminar);
            this.Controls.Add(this.button1Anyadir);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label6Numero);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label4Hora);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label7Fecha);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label5Personas);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label3Nombre);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2Mesas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Mesa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Mesa";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Mesa_FormClosing);
            this.Load += new System.EventHandler(this.Mesa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservaMesaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2Mesas;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3Nombre;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5Personas;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label7Fecha;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4Hora;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6Numero;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button1Anyadir;
        private System.Windows.Forms.Button button2Eliminar;
        private System.Windows.Forms.BindingSource reservaMesaBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn horaReservaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaReservaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroComensalesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroTelefonoDataGridViewTextBoxColumn;
    }
}