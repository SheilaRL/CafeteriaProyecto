﻿namespace Cafeteria
{
    partial class InicioEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button7Pedidos = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3Stock = new System.Windows.Forms.Button();
            this.button2Reservas = new System.Windows.Forms.Button();
            this.label1Logo = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.boton3Minimizar = new System.Windows.Forms.Button();
            this.botonAmpliar = new System.Windows.Forms.Button();
            this.botonSalir = new System.Windows.Forms.Button();
            this.panel3Empleado = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.button7Pedidos);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button3Stock);
            this.panel1.Controls.Add(this.button2Reservas);
            this.panel1.Controls.Add(this.label1Logo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(206, 643);
            this.panel1.TabIndex = 0;
            // 
            // button7Pedidos
            // 
            this.button7Pedidos.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button7Pedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7Pedidos.ForeColor = System.Drawing.Color.White;
            this.button7Pedidos.Location = new System.Drawing.Point(27, 375);
            this.button7Pedidos.Name = "button7Pedidos";
            this.button7Pedidos.Size = new System.Drawing.Size(151, 45);
            this.button7Pedidos.TabIndex = 8;
            this.button7Pedidos.Text = "Pedidos";
            this.button7Pedidos.UseVisualStyleBackColor = false;
            this.button7Pedidos.Click += new System.EventHandler(this.button7Pedidos_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Cafeteria.Properties.Resources.bolleria;
            this.pictureBox1.Location = new System.Drawing.Point(12, 73);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(179, 106);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // button3Stock
            // 
            this.button3Stock.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button3Stock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3Stock.ForeColor = System.Drawing.Color.White;
            this.button3Stock.Location = new System.Drawing.Point(27, 472);
            this.button3Stock.Name = "button3Stock";
            this.button3Stock.Size = new System.Drawing.Size(151, 45);
            this.button3Stock.TabIndex = 3;
            this.button3Stock.Text = "Stock";
            this.button3Stock.UseVisualStyleBackColor = false;
            this.button3Stock.Click += new System.EventHandler(this.button3Stock_Click);
            // 
            // button2Reservas
            // 
            this.button2Reservas.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button2Reservas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2Reservas.ForeColor = System.Drawing.Color.White;
            this.button2Reservas.Location = new System.Drawing.Point(27, 271);
            this.button2Reservas.Name = "button2Reservas";
            this.button2Reservas.Size = new System.Drawing.Size(151, 45);
            this.button2Reservas.TabIndex = 2;
            this.button2Reservas.Text = "Reserva mesas";
            this.button2Reservas.UseVisualStyleBackColor = false;
            this.button2Reservas.Click += new System.EventHandler(this.button2Reservas_Click);
            // 
            // label1Logo
            // 
            this.label1Logo.AutoSize = true;
            this.label1Logo.BackColor = System.Drawing.Color.Teal;
            this.label1Logo.Font = new System.Drawing.Font("Verdana", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1Logo.ForeColor = System.Drawing.Color.White;
            this.label1Logo.Location = new System.Drawing.Point(22, 14);
            this.label1Logo.Name = "label1Logo";
            this.label1Logo.Size = new System.Drawing.Size(164, 25);
            this.label1Logo.TabIndex = 0;
            this.label1Logo.Text = "Vita con caffé";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.boton3Minimizar);
            this.panel2.Controls.Add(this.botonAmpliar);
            this.panel2.Controls.Add(this.botonSalir);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(206, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(869, 39);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // boton3Minimizar
            // 
            this.boton3Minimizar.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boton3Minimizar.Location = new System.Drawing.Point(740, 3);
            this.boton3Minimizar.Name = "boton3Minimizar";
            this.boton3Minimizar.Size = new System.Drawing.Size(35, 33);
            this.boton3Minimizar.TabIndex = 2;
            this.boton3Minimizar.Text = "-";
            this.boton3Minimizar.UseVisualStyleBackColor = true;
            // 
            // botonAmpliar
            // 
            this.botonAmpliar.Location = new System.Drawing.Point(781, 3);
            this.botonAmpliar.Name = "botonAmpliar";
            this.botonAmpliar.Size = new System.Drawing.Size(35, 33);
            this.botonAmpliar.TabIndex = 1;
            this.botonAmpliar.Text = "[]";
            this.botonAmpliar.UseVisualStyleBackColor = true;
            // 
            // botonSalir
            // 
            this.botonSalir.Location = new System.Drawing.Point(822, 3);
            this.botonSalir.Name = "botonSalir";
            this.botonSalir.Size = new System.Drawing.Size(35, 33);
            this.botonSalir.TabIndex = 0;
            this.botonSalir.Text = "X";
            this.botonSalir.UseVisualStyleBackColor = true;
            this.botonSalir.Click += new System.EventHandler(this.botonSalir_Click);
            // 
            // panel3Empleado
            // 
            this.panel3Empleado.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3Empleado.Location = new System.Drawing.Point(206, 39);
            this.panel3Empleado.Name = "panel3Empleado";
            this.panel3Empleado.Size = new System.Drawing.Size(869, 604);
            this.panel3Empleado.TabIndex = 1;
            this.panel3Empleado.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // InicioEmpleado
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1075, 643);
            this.Controls.Add(this.panel3Empleado);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "InicioEmpleado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "InicioEmpleado";
            this.Load += new System.EventHandler(this.InicioEmpleado_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3Empleado;
        private System.Windows.Forms.Button botonSalir;
        private System.Windows.Forms.Button boton3Minimizar;
        private System.Windows.Forms.Button botonAmpliar;
        private System.Windows.Forms.Label label1Logo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3Stock;
        private System.Windows.Forms.Button button2Reservas;
        private System.Windows.Forms.Button button7Pedidos;
    }
}