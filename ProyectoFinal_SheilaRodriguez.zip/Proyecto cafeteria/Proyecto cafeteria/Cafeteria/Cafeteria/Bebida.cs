﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    public class Bebida : Producto
    {
        private int codigoBebida;
        private string nombreBebida;
        private double precioBebida;
        private int stock;
        private string tipoBebida;

        public Bebida(string codigoProducto, string nombreProducto, int cantidad, string precioProducto) 
            : base(codigoProducto, nombreProducto, cantidad, precioProducto)
        {
        }

        public int getCodigoBebida()
        {
            return codigoBebida;
        }

        public void setCodigoBebida(int codigoBebida)
        {
            this.codigoBebida = codigoBebida;
        }

        public string getNombreBebida()
        {
            return nombreBebida;
        }

        public void setNombrebBebida(string nombreBebida)
        {
            this.nombreBebida = nombreBebida;
        }

        public double getPrecioBebida()
        {
            return precioBebida;
        }

        public void setPrecioBebida(double precioBebida)
        {
            this.precioBebida = precioBebida;
        }

        public int getStock()
        {
            return stock;
        }

        public void setStock(int stock)
        {
            this.stock = stock;
        }

        public string getTipoBebida()
        {
            return tipoBebida;
        }

        public void setTipoBebida(string tipoBebida)
        {
            this.tipoBebida = tipoBebida;
        }
    }
}
