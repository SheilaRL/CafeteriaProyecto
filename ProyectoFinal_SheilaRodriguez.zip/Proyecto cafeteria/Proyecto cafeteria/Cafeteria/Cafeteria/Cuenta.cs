﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria
{
    public partial class Cuenta : Form
    {
        public Cuenta()
        {
            InitializeComponent();
        }

        private void labelTotal_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            CalcularCambio();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            CalcularCambio();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void botonPagar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Gracias por su compra!");
            this.Close();
        }

        public void CalcularCambio() 
        {
            if (double.TryParse(textBox6.Text, out double total) && double.TryParse(textBox1.Text, out double devolver))
            {
                double cambio = devolver - total;
                textBox2.Text = cambio.ToString("0.00");
            }

            else
            {
                textBox2.Text = string.Empty;
            }
        }

    }
}
